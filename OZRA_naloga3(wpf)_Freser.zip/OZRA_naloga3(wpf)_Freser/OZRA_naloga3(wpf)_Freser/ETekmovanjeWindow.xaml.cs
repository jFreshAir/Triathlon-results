﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OZRA_naloga3_wpf__Freser.Models;
using System.Net.Http.Headers;
using System.Collections.ObjectModel;
using Newtonsoft.Json;

namespace OZRA_naloga3_wpf__Freser
{
    /// <summary>
    /// Interaction logic for ETekmovanjeWindow.xaml
    /// </summary>
    public partial class ETekmovanjeWindow : Window
    {
        private void NastaviSlovar(bool us)
        {
            if (!us)
            {
                slovar = new();
                slovar.Source = new Uri("/Resources/StringResource.xaml", UriKind.RelativeOrAbsolute);
                this.Resources.MergedDictionaries.Add(slovar);
            }
            else
            {
                slovar = new();
                slovar.Source = new Uri("/Resources/StringResource.us-EN.xaml", UriKind.RelativeOrAbsolute);
                this.Resources.MergedDictionaries.Add(slovar);
            }
        }

        public ResourceDictionary slovar;
        public bool EN;

        public Tekmovanje obdelovanoTekmovanje;
        public bool novo = false;

        public ObservableCollection<Tekmovanje> trenutniSeznam;
        public List<Tekmovanje> trenutniList;


        static HttpClient client;
        PoslovnaLogika logika = new();

        Uporabnik u;

        public ETekmovanjeWindow(Uporabnik prijavljen, HttpClient MyClient, bool en)
        {
            InitializeComponent();

            client = MyClient;
            u = prijavljen;

            EN = en;
            NastaviSlovar(EN);

            if(!u.Admin)
                btnNovoTekmovanje.IsEnabled = false;

            HttpResponseMessage response = client.GetAsync("api/Tekmovanje").Result;
            if (response.IsSuccessStatusCode)
            {

                listBoxTekmovanja.ItemsSource = response.Content.ReadAsAsync<IEnumerable<Tekmovanje>>().Result;
                //trenutniList = ((IEnumerable<Tekmovanje>)this.listBoxTekmovanja.ItemsSource).ToList();
                CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(listBoxTekmovanja.ItemsSource);
                view.Filter = FilterTekmovanj;
            }
            else
                MessageBox.Show("");
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            listBoxTekmovanja.SelectedItem = null;

            obdelovanoTekmovanje = null;

            txtBoxIskanjeTekmovanje.Text = String.Empty;
            txtBoxLetoTekmovanja.Text = String.Empty;
            txtBoxNazivTekmovanja.Text = String.Empty;

            // NA NOVO NASTAVI SOURCE

            HttpResponseMessage response = client.GetAsync("api/Tekmovanje").Result;
            if (response.IsSuccessStatusCode)
                listBoxTekmovanja.ItemsSource = response.Content.ReadAsAsync<IEnumerable<Tekmovanje>>().Result;
        }

        private void btnLetoAsc_Click(object sender, RoutedEventArgs e)
        {
            HttpResponseMessage response = client.GetAsync("api/Tekmovanje/stara").Result;
            if(response.IsSuccessStatusCode)
                listBoxTekmovanja.ItemsSource = response.Content.ReadAsAsync<IEnumerable<Tekmovanje>>().Result;
        }

        private void btnLetoDesc_Click(object sender, RoutedEventArgs e)
        {
            HttpResponseMessage response = client.GetAsync("api/Tekmovanje/nova").Result;
            if (response.IsSuccessStatusCode)
                listBoxTekmovanja.ItemsSource = response.Content.ReadAsAsync<IEnumerable<Tekmovanje>>().Result;
        }

        private void btnShraniTekmovanje_Click(object sender, RoutedEventArgs e)
        {

            if (obdelovanoTekmovanje != null)
            {
                if (txtBoxNazivTekmovanja.Text != string.Empty && txtBoxLetoTekmovanja.Text != string.Empty)
                {
                    if (novo)
                    {
                        //DODAJANJE - POST
                        obdelovanoTekmovanje.Ime = txtBoxNazivTekmovanja.Text;
                        if (int.TryParse(txtBoxLetoTekmovanja.Text, out _))
                        {
                            obdelovanoTekmovanje.Leto = int.Parse(txtBoxLetoTekmovanja.Text); 
                        }
                        else
                        {
                            MessageBox.Show(slovar["letoSt"].ToString());
                            return;
                        }    

                        var response = client.PostAsJsonAsync("api/Tekmovanje", obdelovanoTekmovanje).Result;

                        if (response.IsSuccessStatusCode)
                        {
                            MessageBox.Show(slovar["uspesno"].ToString());
                            txtBoxLetoTekmovanja.Text = String.Empty;
                            txtBoxNazivTekmovanja.Text = String.Empty;

                            HttpResponseMessage response2 = client.GetAsync("api/Tekmovanje").Result;
                            if (response2.IsSuccessStatusCode)
                                listBoxTekmovanja.ItemsSource = response2.Content.ReadAsAsync<IEnumerable<Tekmovanje>>().Result;
                            
                        }
                        else
                            MessageBox.Show(slovar["neuspesno"].ToString());
                    }
                    else
                    {
                        //SHRANJEVANJE - PUT
                        obdelovanoTekmovanje.Ime = txtBoxNazivTekmovanja.Text;
                        if (int.TryParse(txtBoxLetoTekmovanja.Text, out _))
                        {
                            obdelovanoTekmovanje.Leto = int.Parse(txtBoxLetoTekmovanja.Text);
                        }
                        else
                        {
                            MessageBox.Show(slovar["letoSt"].ToString());
                            return;
                        }

                        var response = client.PutAsJsonAsync("api/Tekmovanje", obdelovanoTekmovanje).Result;

                        if (response.IsSuccessStatusCode)
                        {
                            MessageBox.Show(slovar["uspesno"].ToString());
                            txtBoxLetoTekmovanja.Text = String.Empty;
                            txtBoxNazivTekmovanja.Text = String.Empty;

                            HttpResponseMessage response2 = client.GetAsync("api/Tekmovanje").Result;
                            if (response2.IsSuccessStatusCode)
                                listBoxTekmovanja.ItemsSource = response2.Content.ReadAsAsync<IEnumerable<Tekmovanje>>().Result;

                        }
                        else
                            MessageBox.Show(slovar["neuspesno"].ToString());
                    }
                }
                else
                    MessageBox.Show(slovar["vnesiVsePodatke"].ToString());
            }
            else
                MessageBox.Show(slovar["izberiTekmovanje"].ToString());

        }

        private void btnDeleteTekmovanje_Click(object sender, RoutedEventArgs e)
        {
            if (obdelovanoTekmovanje != null)
            {
                string url = "api/Tekmovanje/" + obdelovanoTekmovanje.Id.ToString(); 

                var response = client.DeleteAsync(url).Result;

                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show(slovar["uspesno"].ToString());
                    txtBoxLetoTekmovanja.Text = String.Empty;
                    txtBoxNazivTekmovanja.Text = String.Empty;

                    HttpResponseMessage response2 = client.GetAsync("api/Tekmovanje").Result;
                    if (response2.IsSuccessStatusCode)
                        listBoxTekmovanja.ItemsSource = response2.Content.ReadAsAsync<IEnumerable<Tekmovanje>>().Result;
                }
                else
                    MessageBox.Show(slovar["neuspesno"].ToString());
            }
        }
        
        private void btnNovoTekmovanje_Click(object sender, RoutedEventArgs e)
        {
            obdelovanoTekmovanje = new Tekmovanje();
            novo = true;
            lblNovoTekmovanje.Visibility = Visibility.Visible;
            txtBoxLetoTekmovanja.Text = string.Empty;
            txtBoxNazivTekmovanja.Text = string.Empty;

        }

        private void listBoxTekmovanja_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            novo = false;
            obdelovanoTekmovanje = listBoxTekmovanja.SelectedItem as Tekmovanje;
            if (obdelovanoTekmovanje != null)
            {
                txtBoxNazivTekmovanja.Text = obdelovanoTekmovanje.Ime;
                txtBoxLetoTekmovanja.Text = obdelovanoTekmovanje.Leto.ToString(); 
            }
            else
            {
                txtBoxNazivTekmovanja.Text = String.Empty;
                txtBoxLetoTekmovanja.Text = string.Empty;
            }
              
        }
        private void btnIzvoz_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder izvoz = new();
            foreach(Tekmovanje item in listBoxTekmovanja.Items)
            {
                if (item.Izvoz)
                {
                    izvoz.Append(item.ToString() + '\n');
                }
            }

            if (izvoz.Length > 0)
            {
                MessageBox.Show(logika.SaveToFile(izvoz.ToString()));
            }
            else
                MessageBox.Show(slovar["tekmovanjeIzvoz"].ToString());
        }

        private void btnUvoz_Click(object sender, RoutedEventArgs e)
        {

        }

        private void txtBoxNazivTekmovanja_GotFocus(object sender, RoutedEventArgs e)
        {
            lblNovoTekmovanje.Visibility = Visibility.Hidden;
        }

        private void SelectedTekmovanjeIzvoz(object sender, MouseButtonEventArgs e)
        {
            Tekmovanje izbrano = listBoxTekmovanja.SelectedItem as Tekmovanje;

            if (izbrano.Izvoz)
            { 
                izbrano.Izvoz = false;
            }
            else
                izbrano.Izvoz = true;
        }

        private void txtBoxIskanjeTekmovanje_TextChanged(object sender, TextChangedEventArgs e)
        {
            CollectionViewSource.GetDefaultView(listBoxTekmovanja.ItemsSource).Refresh();
        }

        private bool FilterTekmovanj(object item)
        {
            if (String.IsNullOrEmpty(txtBoxIskanjeTekmovanje.Text))
                return true;
            else
                return ((item as Tekmovanje).ToString().IndexOf(txtBoxIskanjeTekmovanje.Text, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            IzbiraWindow okno = new(client, EN, u);
            okno.Show();
        }

        private void btnRezultatiTekmovanja_Click(object sender, RoutedEventArgs e)
        {
            if (listBoxTekmovanja.SelectedItem == null)
                return;

            ERezultatiWindow okno = new(u, client, EN, null, obdelovanoTekmovanje);
            okno.ShowDialog();
        }
    }
}
