﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OZRA_naloga3_wpf__Freser.Models;

namespace OZRA_naloga3_wpf__Freser
{
    /// <summary>
    /// Interaction logic for IzbiraWindow.xaml
    /// </summary>
    public partial class IzbiraWindow : Window
    {
        private void NastaviSlovar(bool en)
        {
            if (!en)
            {
                slovar = new();
                slovar.Source = new Uri("/Resources/StringResource.xaml", UriKind.RelativeOrAbsolute);
                this.Resources.MergedDictionaries.Add(slovar);
            }
            else
            {
                slovar = new();
                slovar.Source = new Uri("/Resources/StringResource.us-EN.xaml", UriKind.RelativeOrAbsolute);
                this.Resources.MergedDictionaries.Add(slovar);
            }
        }

        public ResourceDictionary slovar;
        public bool EN;

        public Uporabnik u;
        HttpClient client;
        public IzbiraWindow(HttpClient MyClient, bool en, Uporabnik prijavljen = null)
        {
            InitializeComponent();

            client = MyClient;
            //client.BaseAddress = new Uri("https://localhost:7142/");
            //client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            u = prijavljen;

            lblUporabniskoIme.Content = prijavljen.UporabniskoIme;
            if (prijavljen.Admin)
            {
                btnIzbiraUporabniki.IsEnabled = true;
            }

            EN = en;
            NastaviSlovar(EN);

        }

        private void btnIzbiraTekmovalci_Click(object sender, RoutedEventArgs e)
        {
            ETekmovalecWindow tekmovalecW = new(u, client, EN);
            tekmovalecW.Show();
            Close();
        }

        private void btnIzbiraTekmovanja_Click(object sender, RoutedEventArgs e)
        {
            ETekmovanjeWindow tekmovanjeW = new(u, client, EN);
            tekmovanjeW.Show();
            Close();
        }

        private void btnIzbiraRezultati_Click(object sender, RoutedEventArgs e)
        {
            ERezultatiWindow rezultatW = new(u, client, EN);
            rezultatW.Show();
            Close();
        }

        private void btnIzbiraUporabniki_Click(object sender, RoutedEventArgs e)
        {
            EUporabnikiWindow uporabnikiW = new(u, client, EN);
            uporabnikiW.Show();
            Close();

            //Hide();

            //if (uporabnikiW.ShowDialog() == false)
            //    Show();
        }

        private void btnOdjava_Click(object sender, RoutedEventArgs e)
        {
            MainWindow prijava = new MainWindow();
            prijava.Show();
            Close();
        }

        private void btnUrejanje_Click(object sender, RoutedEventArgs e)
        {
            UrejanjeProfila urejanje = new(u, client, EN);
            if (urejanje.ShowDialog() == true)
            {
                lblUporabniskoIme.Content = urejanje.urejan.UporabniskoIme;
            }
            else
                lblUporabniskoIme.Content = urejanje.urejan.UporabniskoIme;

        }
    }
}
