﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace OZRA_naloga3_wpf__Freser
{
    public class PoslovnaLogika
    {

        public string ObjectToString<T>(T entity)
        {
            StringBuilder sb = new StringBuilder();
            // Vsi propertiji
            PropertyInfo[] properties = typeof(T).GetProperties();
            // Zadni property, da ne dodas vejice
            PropertyInfo last = properties.Last();

            foreach (PropertyInfo property in properties)
            {
                if (property.GetValue(entity) == null)
                    sb.Append("EMPTY");
                else
                    sb.Append(property.GetValue(entity).ToString());

                if (!property.Equals(last))
                    sb.Append(',');
            }

            return sb.ToString();
        }

        public string SaveToFile(string text)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.InitialDirectory = @"C:\FERI\OZRA\Izvozi";
            sfd.Filter = "txt(*.txt)|*.txt";
            if (sfd.ShowDialog() == true)
            {
                File.WriteAllText(sfd.FileName, text);
                return "Datoteka uspešno shranjena.";
            }

            return "Napaka pri shranjevanju datoteke";
        }



    }
}
