﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OZRA_naloga3_wpf__Freser.Models;
using System.Net.Http.Headers;
using System.Collections.ObjectModel;
using Newtonsoft.Json;
using System.Net.Http;

namespace OZRA_naloga3_wpf__Freser
{
    /// <summary>
    /// Interaction logic for ETekmovalecWindow.xaml
    /// </summary>
    public partial class ETekmovalecWindow : Window
    {
        private void NastaviSlovar(bool us)
        {
            if (!us)
            {
                slovar = new();
                slovar.Source = new Uri("/Resources/StringResource.xaml", UriKind.RelativeOrAbsolute);
                this.Resources.MergedDictionaries.Add(slovar);
            }
            else
            {
                slovar = new();
                slovar.Source = new Uri("/Resources/StringResource.us-EN.xaml", UriKind.RelativeOrAbsolute);
                this.Resources.MergedDictionaries.Add(slovar);
            }
        }

        public ResourceDictionary slovar;
        public bool EN;

        public Tekmovalec obdelovan;
        public bool novo = false;

        public ObservableCollection<Tekmovalec> trenutniSeznam;

        static HttpClient client;
        PoslovnaLogika logika = new();

        public Uporabnik u;

        public ETekmovalecWindow(Uporabnik prijavljen, HttpClient MyClient, bool en)
        {
            InitializeComponent();

            client = MyClient;
            u = prijavljen;

            EN = en;
            NastaviSlovar(EN);

            HttpResponseMessage response = client.GetAsync("api/Tekmovalec").Result;
            if (response.IsSuccessStatusCode)
            {

                listBoxTekmovalec.ItemsSource = response.Content.ReadAsAsync<IEnumerable<Tekmovalec>>().Result;
                //trenutniList = ((IEnumerable<Tekmovanje>)this.listBoxTekmovanja.ItemsSource).ToList();
                CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(listBoxTekmovalec.ItemsSource);
                view.Filter = FilterTekmovalcev;
            }
            else
                MessageBox.Show("");
        }

        private bool FilterTekmovalcev(object item)
        {
            if (String.IsNullOrEmpty(txtBoxIskanjeTekmovalec.Text))
                return true;
            else
                return ((item as Tekmovalec).ToString().IndexOf(txtBoxIskanjeTekmovalec.Text, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            listBoxTekmovalec.SelectedItem = null;

            obdelovan = null;

            txtBoxIme.Text = String.Empty;
            txtBoxIskanjeTekmovalec.Text = String.Empty;

            HttpResponseMessage response = client.GetAsync("api/Tekmovalec").Result;
            if (response.IsSuccessStatusCode)
                listBoxTekmovalec.ItemsSource = response.Content.ReadAsAsync<IEnumerable<Tekmovalec>>().Result;
        }

        private void btnImeAsc_Click(object sender, RoutedEventArgs e)
        {
            HttpResponseMessage response = client.GetAsync("api/Tekmovalec/asc").Result;
            if (response.IsSuccessStatusCode)
                listBoxTekmovalec.ItemsSource = response.Content.ReadAsAsync<IEnumerable<Tekmovalec>>().Result;
        }

        private void btnImeDesc_Click(object sender, RoutedEventArgs e)
        {
            HttpResponseMessage response = client.GetAsync("api/Tekmovalec/desc").Result;
            if (response.IsSuccessStatusCode)
                listBoxTekmovalec.ItemsSource = response.Content.ReadAsAsync<IEnumerable<Tekmovalec>>().Result;
        }

        private void btnIzvoz_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder izvoz = new();
            foreach(Tekmovalec item in listBoxTekmovalec.Items)
            {
                if(item.Izvoz)
                    izvoz.Append(item.ToString() + '\n');
            }

            if (izvoz.Length > 0)
                MessageBox.Show(logika.SaveToFile(izvoz.ToString()));
            else
                MessageBox.Show(slovar["tekmovalecIzvoz"].ToString());
        }

        private void btnUvoz_Click(object sender, RoutedEventArgs e)
        {

        }

        private void txtBoxIskanjeTekmovalec_TextChanged(object sender, TextChangedEventArgs e)
        {
            CollectionViewSource.GetDefaultView(listBoxTekmovalec.ItemsSource).Refresh();
        }

        private void listBoxTekmovalec_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            novo = false;
            obdelovan = listBoxTekmovalec.SelectedItem as Tekmovalec;
            if(obdelovan != null)
            {
                txtBoxIme.Text = obdelovan.Ime;
            }
            else
            {
                txtBoxIme.Text = String.Empty;
            }
        }

        private void listBoxTekmovalec_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (listBoxTekmovalec.SelectedItem == null)
                return;
            Tekmovalec izbran = listBoxTekmovalec.SelectedItem as Tekmovalec;

            if (izbran.Izvoz)
            {
                izbran.Izvoz = false;
            }
            else
                izbran.Izvoz = true;
        }
        

        private void btnNovTekmovalec_Click(object sender, RoutedEventArgs e)
        {
            obdelovan = new Tekmovalec();
            novo = true;
            lblNovTekmovalec.Visibility = Visibility.Visible;
            txtBoxIme.Text = String.Empty;
        }

        private void txtBoxIme_GotFocus(object sender, RoutedEventArgs e)
        {
            lblNovTekmovalec.Visibility = Visibility.Hidden;
        }
        
        
        private void btnDeleteTekmovalec_Click(object sender, RoutedEventArgs e)
        {
            if(obdelovan != null)
            {
                string url = "api/Tekmovalec/" + obdelovan.Id.ToString();

                var response = client.DeleteAsync(url).Result;

                if(response.IsSuccessStatusCode)
                {
                    MessageBox.Show(slovar["uspesno"].ToString());
                    txtBoxIme.Text = String.Empty;

                    HttpResponseMessage response2 = client.GetAsync("api/Tekmovalec").Result;
                    if (response2.IsSuccessStatusCode)
                        listBoxTekmovalec.ItemsSource = response2.Content.ReadAsAsync<IEnumerable<Tekmovalec>>().Result;
                }
            
            }
        }
        
        
        private void btnShraniTekmovalec_Click(object sender, RoutedEventArgs e)
        {
            if(obdelovan == null)
            {
                MessageBox.Show(slovar["tekmovalecErr"].ToString());
                return;
            }

            if(txtBoxIme.Text == String.Empty)
            {
                MessageBox.Show(slovar["vnesiVsePodatke"].ToString());
                return;
            }

            if(novo)
            { 
                obdelovan.Ime = txtBoxIme.Text;

                var response = client.PostAsJsonAsync("api/Tekmovalec", obdelovan).Result;

                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show(slovar["uspesno"].ToString());
                    txtBoxIme.Text = String.Empty;

                    HttpResponseMessage response2 = client.GetAsync("api/Tekmovalec").Result;
                    if (response2.IsSuccessStatusCode)
                        listBoxTekmovalec.ItemsSource = response2.Content.ReadAsAsync<IEnumerable<Tekmovalec>>().Result;
                }
                else
                    MessageBox.Show(slovar["neuspesno"].ToString());
            }
            else
            {
                obdelovan.Ime = txtBoxIme.Text;

                var response = client.PutAsJsonAsync("api/Tekmovalec", obdelovan).Result;

                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show(slovar["uspesno"].ToString());
                    txtBoxIme.Text = String.Empty;

                    HttpResponseMessage response2 = client.GetAsync("api/Tekmovalec").Result;
                    if (response2.IsSuccessStatusCode)
                        listBoxTekmovalec.ItemsSource = response2.Content.ReadAsAsync<IEnumerable<Tekmovalec>>().Result;
                }
                else
                    MessageBox.Show(slovar["neuspesno"].ToString());
            }

        }

        private void btnBest_Click(object sender, RoutedEventArgs e)
        {
            HttpResponseMessage response = client.GetAsync("api/Tekmovalec/best").Result;
            if (response.IsSuccessStatusCode)
                listBoxTekmovalec.ItemsSource = response.Content.ReadAsAsync<IEnumerable<Tekmovalec>>().Result;
        }

        private void btnBestCat_Click(object sender, RoutedEventArgs e)
        {
            HttpResponseMessage response = client.GetAsync("api/Tekmovalec/category").Result;
            if (response.IsSuccessStatusCode)
                listBoxTekmovalec.ItemsSource = response.Content.ReadAsAsync<IEnumerable<Tekmovalec>>().Result;
        }

        private void btnBestGen_Click(object sender, RoutedEventArgs e)
        {
            HttpResponseMessage response = client.GetAsync("api/Tekmovalec/gender").Result;
            if (response.IsSuccessStatusCode)
                listBoxTekmovalec.ItemsSource = response.Content.ReadAsAsync<IEnumerable<Tekmovalec>>().Result;
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            IzbiraWindow okno = new(client, EN, u);
            okno.Show();
        }

        private void btnRezultatiTekmovalca_Click(object sender, RoutedEventArgs e)
        {
            if (listBoxTekmovalec.SelectedItem == null)
                return;


            ERezultatiWindow okno = new(u, client, EN, obdelovan);
            okno.ShowDialog();
        }
    }
}
