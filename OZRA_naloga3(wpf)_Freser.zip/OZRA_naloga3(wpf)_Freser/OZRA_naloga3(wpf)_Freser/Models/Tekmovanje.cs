﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace OZRA_naloga3_wpf__Freser.Models
{
    [Table("Tekmovanja")]
    public partial class Tekmovanje : INotifyPropertyChanged
    {
        public Tekmovanje()
        {
            Rezultati = new HashSet<Rezultat>();
        }

        [Key]
        public int Id { get; set; }
        public string Ime { get; set; } = null!;
        public int Leto { get; set; }

        [InverseProperty("Tekmovanje")]
        public virtual ICollection<Rezultat> Rezultati { get; set; }

        [NotMapped]
        private bool izvoz { get; set; }
        [NotMapped]
        public bool Izvoz
        {
            get { return izvoz; }
            set
            {
                izvoz = value;
                OnPropertyChanged("Izvoz");
            }
        }

        [NotMapped]
        public bool IsSelected { get; set; } = false;

        //public string Iskanje
        //{
        //    get
        //    {
        //        return Id.ToString() + ' ' + Ime + ' ' + Leto.ToString();
        //    }
        //}

        public string Izpis
        {
            get
            {
                return "ID: " + Id.ToString() + "   | " + Ime + "    | " + Leto.ToString();
            }
        }

        public override string ToString()
        {
            return Id.ToString() + ',' + Ime + ',' + Leto.ToString();
        }


        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged(string propName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
        }
    }
}
