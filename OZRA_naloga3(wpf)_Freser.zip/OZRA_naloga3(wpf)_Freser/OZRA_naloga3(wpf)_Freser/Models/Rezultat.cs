﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace OZRA_naloga3_wpf__Freser.Models
{
    [Table("Rezultati")]
    [Index("TekmovalecId", Name = "IX_Rezultati_TekmovalecId")]
    [Index("TekmovanjeId", Name = "IX_Rezultati_TekmovanjeId")]
    public partial class Rezultat : INotifyPropertyChanged
    {
        [Key]
        public int Id { get; set; }
        [Column("UvrstitevVSpolu")]
        public string? UvrstitevVspolu { get; set; }
        [Column("UvrstitevVStarKat")]
        public string? UvrstitevVstarKat { get; set; }
        public string? KoncnaUvrstitev { get; set; }
        public string? StartnaSt { get; set; }
        public string? Kategorija { get; set; }
        public string? Starost { get; set; }
        public string? KrajT { get; set; }
        public string? DrzavaT { get; set; }
        public string? Poklic { get; set; }
        public string? Tocke { get; set; }
        public string? CasPlavanje { get; set; }
        public string? DolzinaPlavanje { get; set; }
        public string? Tranzicija1 { get; set; }
        public string? CasKolo { get; set; }
        public string? DolzinaKolo { get; set; }
        public string? Tranzicija2 { get; set; }
        public string? CasTek { get; set; }
        public string? DolzinaTek { get; set; }
        public string? SkupniCas { get; set; }
        public int TekmovalecId { get; set; }
        public int TekmovanjeId { get; set; }

        [ForeignKey("TekmovalecId")]
        [InverseProperty("Rezultati")]
        public virtual Tekmovalec Tekmovalec { get; set; } = null!;
        [ForeignKey("TekmovanjeId")]
        [InverseProperty("Rezultati")]
        public virtual Tekmovanje Tekmovanje { get; set; } = null!;

        private bool izvoz;

        [NotMapped]
        public bool Izvoz {
            get { return izvoz; }
            set
            {
                izvoz = value;
                OnPropertyChanged("Izvoz");
            }
        }


        public string Izpis
        {
            get
            {
                return "ID: " + Id.ToString() + "   | " + KoncnaUvrstitev + " | " + SkupniCas;
            }
        }

        public override string ToString()
        {
            string imeTekmovalca = Tekmovalec == null ? "---" : Tekmovalec.Ime;

            return imeTekmovalca + ',' + UvrstitevVspolu + ',' + UvrstitevVstarKat + ','
                + KoncnaUvrstitev + ',' + StartnaSt + ',' + Kategorija + ',' + Starost + ','
                + KrajT + ',' + DrzavaT + ',' + Poklic + ',' + CasPlavanje + ',' + DolzinaPlavanje + ','
                + Tranzicija1 + ',' + CasKolo + ',' + DolzinaKolo + ',' + Tranzicija2 + ',' + CasTek + ','
                + DolzinaTek + ',' + SkupniCas;
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged(string propName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
        }

    }
}
