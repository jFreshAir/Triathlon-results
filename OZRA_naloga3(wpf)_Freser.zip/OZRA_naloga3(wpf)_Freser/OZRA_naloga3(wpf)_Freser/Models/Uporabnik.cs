﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace OZRA_naloga3_wpf__Freser.Models
{
    [Table("Uporabniki")]
    public partial class Uporabnik : INotifyPropertyChanged
    {
        [Key]
        public int Id { get; set; }
        public string UporabniskoIme { get; set; } = null!;
        public string Geslo { get; set; } = null!;

        private bool admin { get; set; }
        public bool Admin {
            get
            {
                return admin;
            }
            set
            {
                admin = value;
                OnPropertyChanged(nameof(Admin));
                OnPropertyChanged(nameof(stringAdmin));
                OnPropertyChanged(nameof(Izpis));
            }
        }

        private string stringAdmin { 
            get
            {
                return admin ? "Admin" : "User";
            } 
        }

        public string Izpis
        {
            get
            {
                return "ID: " + Id.ToString() + "   | " + UporabniskoIme + "               | " + stringAdmin;
            }
        }

        public override string ToString()
        {
            return Id.ToString() + ',' + UporabniskoIme;
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged(string propName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
        }
    }
}
