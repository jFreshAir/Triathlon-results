﻿using OZRA_naloga3_wpf__Freser.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OZRA_naloga3_wpf__Freser
{
    /// <summary>
    /// Interaction logic for UrejanjeProfila.xaml
    /// </summary>
    public partial class UrejanjeProfila : Window
    {
        private void NastaviSlovar(bool us)
        {
            if (!us)
            {
                slovar = new();
                slovar.Source = new Uri("/Resources/StringResource.xaml", UriKind.RelativeOrAbsolute);
                this.Resources.MergedDictionaries.Add(slovar);
            }
            else
            {
                slovar = new();
                slovar.Source = new Uri("/Resources/StringResource.us-EN.xaml", UriKind.RelativeOrAbsolute);
                this.Resources.MergedDictionaries.Add(slovar);
            }
        }

        public ResourceDictionary slovar;
        public bool EN;

        public Uporabnik urejan;
        HttpClient client;
        public UrejanjeProfila(Uporabnik u, HttpClient MyClient, bool en)
        {
            InitializeComponent();

            client = MyClient;
            urejan = u;

            EN = en;
            NastaviSlovar(EN);

            txtBoxUporabnisko.Text = u.UporabniskoIme;
            txtBoxGeslo.Text = u.Geslo;

            lblAdmin.Visibility = u.Admin ? Visibility.Visible : Visibility.Collapsed;

        }

        private void btnShraniProfil_Click(object sender, RoutedEventArgs e)
        {
            if(txtBoxUporabnisko.Text == null || txtBoxGeslo.Text == null)
            {
                lblError.Content = slovar["vnesiVsePodatke"];
                return;
            }

            if (txtBoxUporabnisko.Text == urejan.UporabniskoIme && txtBoxGeslo.Text == urejan.Geslo)
            {
                lblError.Content = slovar["nespremenjeni"];
                return;
            }

            using (var db = new TriatlonContext())
            {
                Uporabnik poskus = db.Uporabniki.FirstOrDefault(x => x.UporabniskoIme == txtBoxUporabnisko.Text);

                if (poskus != null)
                {
                    lblError.Content = slovar["registracijaZasedeno"];
                    return;
                }

            }

            urejan.UporabniskoIme = txtBoxUporabnisko.Text;
            urejan.Geslo = txtBoxGeslo.Text;

            var response = client.PutAsJsonAsync("api/Uporabnik", urejan).Result;

            if (response.IsSuccessStatusCode)
                lblUspešno.Content = slovar["uspesno"];


        }

        private void txtBoxGeslo_GotFocus(object sender, RoutedEventArgs e)
        {
            lblError.Content = "";
            lblUspešno.Content = "";
        }

        private void txtBoxUporabnisko_GotFocus(object sender, RoutedEventArgs e)
        {
            lblError.Content = "";
            lblUspešno.Content = "";
        }
    }
}
