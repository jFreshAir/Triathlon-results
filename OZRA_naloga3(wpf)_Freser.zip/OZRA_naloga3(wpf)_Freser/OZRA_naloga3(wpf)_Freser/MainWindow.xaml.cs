﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using OZRA_naloga3_wpf__Freser.Models;


namespace OZRA_naloga3_wpf__Freser
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static HttpClient client;
        public ResourceDictionary slovar;
        public bool EN;

        private void NastaviSlovar(bool en)
        {
            if (!en)
            {
                slovar = new();
                slovar.Source = new Uri("/Resources/StringResource.xaml", UriKind.RelativeOrAbsolute);
                this.Resources.MergedDictionaries.Add(slovar); 
            }
            else
            {
                slovar = new();
                slovar.Source = new Uri("/Resources/StringResource.us-EN.xaml", UriKind.RelativeOrAbsolute);
                this.Resources.MergedDictionaries.Add(slovar);
            }
        }
        public MainWindow()
        {
            InitializeComponent();

            Jezik izbiraJezika = new();
            izbiraJezika.ShowDialog();
            EN = izbiraJezika.en;

            txtBoxUporabnisko.Focus();

            NastaviSlovar(EN);

            client = new();
            client.BaseAddress = new Uri("https://localhost:7142/");
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        private void btnPrijava_Click(object sender, RoutedEventArgs e)
        {

            string ime = txtBoxUporabnisko.Text;
            

            //IzbiraWindow izbiraW = new();
            //izbiraW.Show();


            using (var db = new TriatlonContext())
            {
                Uporabnik poskus = db.Uporabniki.FirstOrDefault(x => x.UporabniskoIme == ime);

                if (poskus != null && poskus.Geslo == txtBoxGeslo.Password.ToString())
                {
                    IzbiraWindow izbiraW = new(client, EN, poskus);
                    izbiraW.Show();
                    this.Close();

                    //Hide();
                    //if (izbiraW.ShowDialog() == false)
                    //{
                    //    txtBoxUporabnisko.Text = String.Empty;
                    //    txtBoxGeslo.Text = String.Empty;
                    //    Show();
                    //}
                }
                else
                    lblPrijava.Content = slovar["prijavaErr"];//lblPrijava.Content = "Uporabniško ime ali geslo je napačno";
            }

        }

        private void btnRegistracija_Click(object sender, RoutedEventArgs e)
        {
            if(txtBoxUporabnisko.Text == "" || txtBoxUporabnisko.Text == "")
            {
                lblPrijava.Content = slovar["registracijaError"];
                return;
            }    

            
            string ime = txtBoxUporabnisko.Text;
            string geslo = txtBoxUporabnisko.Text;

            using (var db = new TriatlonContext())
            {
                Uporabnik poskus = db.Uporabniki.FirstOrDefault(x => x.UporabniskoIme == ime);

                if (poskus != null)
                    lblPrijava.Content = slovar["registracijaZasedeno"];
                else
                {
                    Uporabnik novi = new() { UporabniskoIme = ime, Geslo = geslo, Admin = false };

                    var response = client.PostAsJsonAsync("api/Uporabnik", novi).Result;
                    if (response.IsSuccessStatusCode)
                        lblPrijava.Content = slovar["registracijaSucc"];
                }


            }
        }
    }
}
