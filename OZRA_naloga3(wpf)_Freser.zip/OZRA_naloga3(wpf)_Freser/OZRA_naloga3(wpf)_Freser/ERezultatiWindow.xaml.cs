﻿using OZRA_naloga3_wpf__Freser.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OZRA_naloga3_wpf__Freser
{
    /// <summary>
    /// Interaction logic for ERezultatiWindow.xaml
    /// </summary>
    public partial class ERezultatiWindow : Window
    {
        private void NastaviSlovar(bool us)
        {
            if (!us)
            {
                slovar = new();
                slovar.Source = new Uri("/Resources/StringResource.xaml", UriKind.RelativeOrAbsolute);
                this.Resources.MergedDictionaries.Add(slovar);
            }
            else
            {
                slovar = new();
                slovar.Source = new Uri("/Resources/StringResource.us-EN.xaml", UriKind.RelativeOrAbsolute);
                this.Resources.MergedDictionaries.Add(slovar);
            }
        }

        public string PreveriText(string txt)
        {
            return txt == string.Empty ? "---" : txt;
        }

        public void IzprazniPolja()
        {
            txtIdTekmovanja.Text = String.Empty;
            txtIdTekmovalca.Text = String.Empty;
            txtUvrstitevSpol.Text = String.Empty;
            txtUvrstitevStarostnaKat.Text = String.Empty;
            txtKoncnaUvrstitev.Text = String.Empty;
            txtStartnaSt.Text = String.Empty;
            txtKategorija.Text = String.Empty;
            txtStarost.Text = String.Empty;
            txtKrajT.Text = String.Empty;
            txtDrzavaT.Text = String.Empty;
            txtPoklicTek.Text = String.Empty;
            txtTocke.Text = String.Empty;
            txtCasPlavanja.Text = String.Empty;
            txtDolzinaPlavanja.Text = String.Empty;
            txtTranzicija1.Text = String.Empty;
            txtCasKolo.Text = String.Empty;
            txtDolzinaKolo.Text = String.Empty;
            txtTranzicija2.Text = String.Empty;
            txtDolzinaTek.Text = String.Empty;
            txtCasTek.Text = String.Empty;
            txtSkupniCas.Text = String.Empty;
        }

        public void RezultatiTekmovalca(int idTekmovalca)
        {
            string url = "api/Rezultat/tekac/" + idTekmovalca.ToString();
            var response = client.GetAsync(url).Result;
            if (response.IsSuccessStatusCode)
                listBoxRezultati.ItemsSource = response.Content.ReadAsAsync<IEnumerable<Rezultat>>().Result;
        }

        public void RezultatiTekmovanja(int idTekmovanja)
        {
            string url = "api/Rezultat/tekma/" + idTekmovanja.ToString();
            var response = client.GetAsync(url).Result;
            if (response.IsSuccessStatusCode)
                listBoxRezultati.ItemsSource = response.Content.ReadAsAsync<IEnumerable<Rezultat>>().Result;
        }

        public ResourceDictionary slovar;
        public bool EN;

        public Rezultat obdelovan;
        public bool nov = false;

        ObservableCollection<Rezultat> trenutniSeznam;

        static HttpClient client;
        PoslovnaLogika logika = new();

        public Uporabnik u;
        public Tekmovanje tekma = null;
        public Tekmovalec tekac = null;
        public ERezultatiWindow(Uporabnik prijavljen, HttpClient MyClient, bool en, Tekmovalec? tekmovalec = null, Tekmovanje? tekmovanje = null)
        {
            InitializeComponent();

            client = MyClient;

            EN = en;
            NastaviSlovar(EN);

            if (tekmovalec != null)
            { 
                tekac = tekmovalec;
                RezultatiTekmovalca(tekac.Id);
            }
            else
            { 
                tekma = tekmovanje;
                RezultatiTekmovanja(tekma.Id);
            }

            CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(listBoxRezultati.ItemsSource);
            view.Filter = FilterRezultatov;

            if (!prijavljen.Admin)
            {
                btnShraniRezultat.IsEnabled = false;
                meni.Visibility = Visibility.Collapsed;
            }

        }

        private void listBoxRezultati_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            lblNovRezultat.Visibility = Visibility.Collapsed;
            nov = false;
            obdelovan = listBoxRezultati.SelectedItem as Rezultat;
            if(obdelovan != null)
            {
                txtIdTekmovanja.Text = obdelovan.TekmovanjeId.ToString();
                txtIdTekmovalca.Text = obdelovan.TekmovalecId.ToString();
                txtUvrstitevSpol.Text = obdelovan.UvrstitevVspolu.ToString();
                txtUvrstitevStarostnaKat.Text = obdelovan.UvrstitevVstarKat.ToString();
                txtKoncnaUvrstitev.Text = obdelovan.KoncnaUvrstitev.ToString();
                txtStartnaSt.Text = obdelovan.StartnaSt.ToString();
                txtKategorija.Text = obdelovan.Kategorija.ToString();
                txtStarost.Text = obdelovan.Starost.ToString();
                txtKrajT.Text = obdelovan.KrajT.ToString();
                txtDrzavaT.Text = obdelovan.DrzavaT.ToString();
                txtPoklicTek.Text = obdelovan.Poklic.ToString();
                txtTocke.Text = obdelovan.Tocke.ToString();
                txtCasPlavanja.Text = obdelovan.CasPlavanje.ToString();
                txtDolzinaPlavanja.Text = obdelovan.DolzinaPlavanje.ToString();
                txtTranzicija1.Text = obdelovan.Tranzicija1.ToString();
                txtCasKolo.Text = obdelovan.CasKolo.ToString();
                txtDolzinaKolo.Text = obdelovan.DolzinaKolo.ToString();
                txtTranzicija2.Text = obdelovan.Tranzicija2.ToString();
                txtDolzinaTek.Text = obdelovan.DolzinaTek.ToString();
                txtCasTek.Text = obdelovan.CasTek.ToString();
                txtSkupniCas.Text = obdelovan.SkupniCas.ToString();

            }
            else
            {
                IzprazniPolja();
            }
        }

        private void listBoxRezultati_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if(listBoxRezultati.SelectedItem == null)
                return;

            Rezultat izbran = listBoxRezultati.SelectedItem as Rezultat;

            if(izbran.Izvoz)
            {
                izbran.Izvoz = false;
            }
            else
                izbran.Izvoz = true;

            
        }

        private void btnIzvozRezultatov_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder izvoz = new();
            foreach(Rezultat item in listBoxRezultati.Items)
            {
                if(item.Izvoz)
                    izvoz.Append(item.ToString() + '\n');
            }

            if (izvoz.Length > 0)
            {
                MessageBox.Show(logika.SaveToFile(izvoz.ToString()));
            }
            else
                MessageBox.Show(slovar["rezultatIzvoz"].ToString());
        }

        private void btnUstvari_Click(object sender, RoutedEventArgs e)
        {
            obdelovan = new();
            nov = true;
            lblNovRezultat.Visibility = Visibility.Visible;

            IzprazniPolja();
        }

        private void btnIzbris_Click(object sender, RoutedEventArgs e)
        {
            if (obdelovan == null)
                return;

            string url = "api/Rezultat/" + obdelovan.Id.ToString();
            
            var response = client.DeleteAsync(url).Result;

            if (response.IsSuccessStatusCode)
            {
                MessageBox.Show(slovar["uspesno"].ToString());

                IzprazniPolja();

                if (tekac != null)
                {
                    RezultatiTekmovalca(tekac.Id);
                }
                else
                {
                    RezultatiTekmovanja(tekma.Id);
                }
            }
            else
                MessageBox.Show(slovar["neuspesno"].ToString());
        }

        private void btnShraniRezultat_Click(object sender, RoutedEventArgs e)
        {
            if(obdelovan == null)
            {
                MessageBox.Show(slovar["rezultatErr"].ToString());
                return;
            }

            if(nov)
            {
                //DODAJANJE POST
                if (txtIdTekmovanja.Text != String.Empty || txtIdTekmovalca.Text != string.Empty)
                {
                    if (int.TryParse(txtIdTekmovanja.Text, out _) && int.TryParse(txtIdTekmovalca.Text, out _))
                    {
                        obdelovan.TekmovanjeId = int.Parse(txtIdTekmovanja.Text);
                        obdelovan.TekmovalecId = int.Parse(txtIdTekmovalca.Text);
                    }
                    else
                    {
                        MessageBox.Show(slovar["rezultatID"].ToString());
                        return;
                    }     
                }
                else
                {
                    MessageBox.Show(slovar["obvezenID"].ToString());
                    return;
                }

                obdelovan.UvrstitevVspolu = PreveriText(txtUvrstitevSpol.Text.ToString());
                obdelovan.UvrstitevVstarKat = PreveriText(txtUvrstitevStarostnaKat.Text);
                obdelovan.KoncnaUvrstitev = PreveriText(txtKoncnaUvrstitev.Text);
                obdelovan.StartnaSt = PreveriText(txtStartnaSt.Text);
                obdelovan.Kategorija = PreveriText(txtKategorija.Text);
                obdelovan.Starost = PreveriText(txtStarost.Text);
                obdelovan.KrajT = PreveriText(txtKrajT.Text);
                obdelovan.DrzavaT = PreveriText(txtDrzavaT.Text);
                obdelovan.Poklic = PreveriText(txtPoklicTek.Text);
                obdelovan.Tocke = PreveriText(txtTocke.Text);
                obdelovan.CasPlavanje = PreveriText(txtCasPlavanja.Text);
                obdelovan.DolzinaPlavanje = PreveriText(txtDolzinaPlavanja.Text);
                obdelovan.Tranzicija1 = PreveriText(txtTranzicija1.Text);
                obdelovan.CasKolo = PreveriText(txtCasKolo.Text);
                obdelovan.DolzinaKolo = PreveriText(txtDolzinaKolo.Text);
                obdelovan.Tranzicija2 = PreveriText(txtTranzicija2.Text);
                obdelovan.DolzinaTek = PreveriText(txtDolzinaTek.Text);
                obdelovan.CasTek = PreveriText(txtCasTek.Text);
                obdelovan.SkupniCas = PreveriText(txtSkupniCas.Text);

                var response = client.PostAsJsonAsync("api/Rezultat", obdelovan).Result;

                if(response.IsSuccessStatusCode)
                {
                    MessageBox.Show(slovar["uspesno"].ToString());
                    IzprazniPolja();

                    if (tekac != null)
                    {
                        RezultatiTekmovalca(tekac.Id);
                    }
                    else
                    {
                        RezultatiTekmovanja(tekma.Id);
                    }
                }
            }
            else
            {
                //POSODABLJANJE - PUT
                if (txtIdTekmovanja.Text != String.Empty || txtIdTekmovalca.Text != string.Empty)
                {
                    if (int.TryParse(txtIdTekmovanja.Text, out _) && int.TryParse(txtIdTekmovalca.Text, out _))
                    {
                        obdelovan.TekmovanjeId = int.Parse(txtIdTekmovanja.Text);
                        obdelovan.TekmovalecId = int.Parse(txtIdTekmovalca.Text);
                    }
                    else
                    {
                        MessageBox.Show(slovar["rezultatID"].ToString());
                        return;
                    }
                }
                else
                {
                    MessageBox.Show(slovar["obvezenID"].ToString());
                    return;
                }

                obdelovan.UvrstitevVspolu = PreveriText(txtUvrstitevSpol.Text.ToString());
                obdelovan.UvrstitevVstarKat = PreveriText(txtUvrstitevStarostnaKat.Text);
                obdelovan.KoncnaUvrstitev = PreveriText(txtKoncnaUvrstitev.Text);
                obdelovan.StartnaSt = PreveriText(txtStartnaSt.Text);
                obdelovan.Kategorija = PreveriText(txtKategorija.Text);
                obdelovan.Starost = PreveriText(txtStarost.Text);
                obdelovan.KrajT = PreveriText(txtKrajT.Text);
                obdelovan.DrzavaT = PreveriText(txtDrzavaT.Text);
                obdelovan.Poklic = PreveriText(txtPoklicTek.Text);
                obdelovan.Tocke = PreveriText(txtTocke.Text);
                obdelovan.CasPlavanje = PreveriText(txtCasPlavanja.Text);
                obdelovan.DolzinaPlavanje = PreveriText(txtDolzinaPlavanja.Text);
                obdelovan.Tranzicija1 = PreveriText(txtTranzicija1.Text);
                obdelovan.CasKolo = PreveriText(txtCasKolo.Text);
                obdelovan.DolzinaKolo = PreveriText(txtDolzinaKolo.Text);
                obdelovan.Tranzicija2 = PreveriText(txtTranzicija2.Text);
                obdelovan.DolzinaTek = PreveriText(txtDolzinaTek.Text);
                obdelovan.CasTek = PreveriText(txtCasTek.Text);
                obdelovan.SkupniCas = PreveriText(txtSkupniCas.Text);

                var response = client.PutAsJsonAsync("api/Rezultat", obdelovan).Result;

                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show(slovar["uspesno"].ToString());
                    IzprazniPolja();

                    if (tekac != null)
                    {
                        RezultatiTekmovalca(tekac.Id);
                    }
                    else
                    {
                        RezultatiTekmovanja(tekma.Id);
                    }
                }
            }
        }

        private bool FilterRezultatov(object item)
        {
            if (String.IsNullOrEmpty(txtBoxIskanje.Text))
                return true;
            else
                return ((item as Rezultat).ToString().IndexOf(txtBoxIskanje.Text, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private void txBoxIskanje_TextChanged(object sender, TextChangedEventArgs e)
        {
            CollectionViewSource.GetDefaultView(listBoxRezultati.ItemsSource).Refresh();
        }
    }
}
