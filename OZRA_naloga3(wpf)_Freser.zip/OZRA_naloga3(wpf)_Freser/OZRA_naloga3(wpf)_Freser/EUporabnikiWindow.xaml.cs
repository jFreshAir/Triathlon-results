﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OZRA_naloga3_wpf__Freser.Models;
using System.Net.Http.Headers;
using System.Collections.ObjectModel;
using Newtonsoft.Json;
using System.Net.Http;

namespace OZRA_naloga3_wpf__Freser
{
    /// <summary>
    /// Interaction logic for EUporabnikiWindow.xaml
    /// </summary>
    public partial class EUporabnikiWindow : Window
    {
        private void NastaviSlovar(bool us)
        {
            if (!us)
            {
                slovar = new();
                slovar.Source = new Uri("/Resources/StringResource.xaml", UriKind.RelativeOrAbsolute);
                this.Resources.MergedDictionaries.Add(slovar);
            }
            else
            {
                slovar = new();
                slovar.Source = new Uri("/Resources/StringResource.us-EN.xaml", UriKind.RelativeOrAbsolute);
                this.Resources.MergedDictionaries.Add(slovar);
            }
        }

        public ResourceDictionary slovar;
        public bool EN;

        public Uporabnik obdelovan;
        public bool nov = false;

        public ObservableCollection<Uporabnik> trenutniSeznam;

        static HttpClient client;
        PoslovnaLogika logika = new();

        public Uporabnik prijavljen;

        public EUporabnikiWindow(Uporabnik u, HttpClient myClient, bool en)
        {
            prijavljen = u;
            client = myClient;
            InitializeComponent();

            EN = en;
            NastaviSlovar(EN);

            HttpResponseMessage response = client.GetAsync("api/Uporabnik").Result;
            if (response.IsSuccessStatusCode)
            {

                listBoxUporabnik.ItemsSource = response.Content.ReadAsAsync<IEnumerable<Uporabnik>>().Result;
                //trenutniList = ((IEnumerable<Tekmovanje>)this.listBoxTekmovanja.ItemsSource).ToList();
                CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(listBoxUporabnik.ItemsSource);
                view.Filter = FilterUporabnikov;
            }
            else
                MessageBox.Show("");
        }

        private bool FilterUporabnikov(object item)
        {
            if (String.IsNullOrEmpty(txtBoxIskanjeUporabnik.Text))
                return true;
            else
                return ((item as Uporabnik).ToString().IndexOf(txtBoxIskanjeUporabnik.Text, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private void txtBoxIskanjeUporabnik_TextChanged(object sender, TextChangedEventArgs e)
        {
            CollectionViewSource.GetDefaultView(listBoxUporabnik.ItemsSource).Refresh();
        }

        private void listBoxUporabnik_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            nov = false;
            obdelovan = listBoxUporabnik.SelectedItem as Uporabnik;
            if (obdelovan != null)
            {
                txtBoxIme.Text = obdelovan.UporabniskoIme;
            }
            else
            {
                txtBoxIme.Text = String.Empty;
            }
        }

        private void listBoxUporabnik_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (listBoxUporabnik.SelectedItem == null)
                return;

            Uporabnik izbran = listBoxUporabnik.SelectedItem as Uporabnik;

            if (izbran.Admin)
            {
                izbran.Admin = false;
            }
            else
                izbran.Admin = true;

            var response = client.PutAsJsonAsync("api/Uporabnik", izbran).Result;

            if(response.IsSuccessStatusCode)
            {
                MessageBox.Show(slovar["uspesno"].ToString());
            }
        }

        private void btnDeleteUporabnik_Click(object sender, RoutedEventArgs e)
        {
            if (obdelovan == null)
                return;

            string url = "api/Uporabnik/" + obdelovan.Id.ToString();

            var response = client.DeleteAsync(url).Result;

            if(response.IsSuccessStatusCode)
            {
                MessageBox.Show(slovar["uspesno"].ToString());
                txtBoxIme.Text = string.Empty;

                HttpResponseMessage response2 = client.GetAsync("api/Uporabnik").Result;
                if (response2.IsSuccessStatusCode)
                    listBoxUporabnik.ItemsSource = response2.Content.ReadAsAsync<IEnumerable<Uporabnik>>().Result;
            }
        }


        private void btnShraniUporabnik_Click(object sender, RoutedEventArgs e)
        {
            if (obdelovan == null)
            {
                MessageBox.Show(slovar["novUporabnik"].ToString());
                return;
            }

            if (txtBoxIme.Text == String.Empty)
            {
                MessageBox.Show(slovar["vnesiVsePodatke"].ToString());
                return;
            }

            if(nov)
            {
                obdelovan.UporabniskoIme = txtBoxIme.Text;

                var response = client.PostAsJsonAsync("api/Uporabnik", obdelovan).Result;

                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show(slovar["uspesno"].ToString());
                    txtBoxIme.Text = string.Empty;

                    HttpResponseMessage response2 = client.GetAsync("api/Uporabnik").Result;
                    if (response2.IsSuccessStatusCode)
                        listBoxUporabnik.ItemsSource = response2.Content.ReadAsAsync<IEnumerable<Uporabnik>>().Result;
                }
                else
                    MessageBox.Show(slovar["neuspesno"].ToString());
            }
            else
            {
                obdelovan.UporabniskoIme = txtBoxIme.Text;

                var response = client.PutAsJsonAsync("api/Uporabnik", obdelovan).Result;

                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show(slovar["uspesno"].ToString());
                    txtBoxIme.Text = string.Empty;

                    HttpResponseMessage response2 = client.GetAsync("api/Uporabnik").Result;
                    if (response2.IsSuccessStatusCode)
                        listBoxUporabnik.ItemsSource = response2.Content.ReadAsAsync<IEnumerable<Uporabnik>>().Result;
                }
                else
                    MessageBox.Show(slovar["neuspesno"].ToString());
            }
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            listBoxUporabnik.SelectedItem = null;

            obdelovan = null;

            txtBoxIme = null;
            txtBoxIskanjeUporabnik = null;

            var response = client.GetAsync("api/Uporabnik").Result;
            if(response.IsSuccessStatusCode)
                listBoxUporabnik.ItemsSource = response.Content.ReadAsAsync<IEnumerable<Uporabnik>>().Result;
        }

        private void btnImeAsc_Click(object sender, RoutedEventArgs e)
        {
            var response = client.GetAsync("api/Uporabnik/asc").Result;
            if(response.IsSuccessStatusCode)
                listBoxUporabnik.ItemsSource= response.Content.ReadAsAsync<IEnumerable<Uporabnik>>().Result;
        }

        private void btnImeDesc_Click(object sender, RoutedEventArgs e)
        {
            var response = client.GetAsync("api/Uporabnik/desc").Result;
            if (response.IsSuccessStatusCode)
                listBoxUporabnik.ItemsSource = response.Content.ReadAsAsync<IEnumerable<Uporabnik>>().Result;
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            IzbiraWindow okno = new(client, EN, prijavljen);
            okno.Show();
        }
    }
}
