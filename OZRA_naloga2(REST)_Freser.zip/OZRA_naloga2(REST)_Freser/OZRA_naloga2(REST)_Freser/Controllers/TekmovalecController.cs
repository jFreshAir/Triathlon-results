﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OZRA_naloga2_REST__Freser.Models;
using OZRA_naloga2_REST__Freser.Repositorys;

namespace OZRA_naloga2_REST__Freser.Controllers
{
    [Route("api/[controller]")]
    public class TekmovalecController : Controller
    {
        public ITekmovalecRepository grupa { get; set; }
        public TekmovalecController([FromServices] ITekmovalecRepository tek)
        {
            grupa = tek;
        }

        // GET: api/Tekmovalec
        [HttpGet]
        public IEnumerable<Tekmovalec> GetAll()
        {
            return grupa.GetAll();
        }

        // GET: api/Tekmovalec/best
        [HttpGet("best")]
        public IEnumerable<Tekmovalec> GetBest()
        {
            return grupa.GetBest();
        }

        // GET: api/Tekmovalec/best
        [HttpGet("category")]
        public IEnumerable<Tekmovalec> GetBestCat()
        {
            return grupa.GetBestCat();
        }

        // GET: api/Tekmovalec/best
        [HttpGet("gender")]
        public IEnumerable<Tekmovalec> GetBestGen()
        {
            return grupa.GetBestGen();
        }

        // GET: api/Tekmovalec/asc
        [HttpGet("asc")]
        public IEnumerable<Tekmovalec> GetAllAsc()
        {
            return grupa.GetAllAsc();
        }

        // GET: api/Tekmovalec/desc
        [HttpGet("desc")]
        public IEnumerable<Tekmovalec> GetAllDesc()
        {
            return grupa.GetAllDesc();
        }

        // GET: api/Tekmovalec/ime/{name}
        [HttpGet("ime/{name}")]
        public IEnumerable<Tekmovalec> ByName(string name)
        {
            return grupa.GetByName(name);
        }

    // GET: api/Tekmovalec/{id}
    [HttpGet("{id}", Name = "GetTekmovalec")]
        public ActionResult Get(int id)
        {
            Tekmovalec iskani = grupa.GetTekmovalec(id);
            if (iskani == null)
                return NotFound("Tekmovalec s tem ključem ne obstaja");

            return new ObjectResult(iskani);
        }

        // POST: api/Tekmovalec
        [HttpPost]
        public ActionResult Create([FromBody] Tekmovalec tekmovalec)
        {
            if (tekmovalec == null)
                return BadRequest("Objekt \"tekmovalec\" ne obstaja");

            bool uspesno = grupa.AddTekmovalca(tekmovalec);
            if (uspesno)
                return CreatedAtRoute("GetTekmovalec", new { id = tekmovalec.Id }, tekmovalec);
            else
                return NoContent();
        }

        // PUT: api/Tekmovalec/{id}
        //[HttpPut("{id}", Name = "UpdateTekmovalec")]
        [HttpPut]
        public ActionResult Update([FromBody] Tekmovalec tekmovalec)
        {
            if (tekmovalec == null)
                return BadRequest("Ključa nista enaka!");

            Tekmovalec stari = grupa.GetTekmovalec(tekmovalec.Id);
            if (stari == null)
                return NotFound("Tekmovalec s tem ključem ne obstaja");
            else
            {
                grupa.Update(tekmovalec);
                return NoContent();
            }
            
        }

        // DELETE: api/Tekmovalec/{id}
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            if (id <= 0)
                return BadRequest("Ključ ni veljaven");

            Tekmovalec stari = grupa.GetTekmovalec(id);
            if (stari == null)
                return NotFound("Tekmovalec s tem ključem ne obstaja");
            else
            {
                grupa.Delete(id);
                return NoContent();
            }
        }

        
    }
}
