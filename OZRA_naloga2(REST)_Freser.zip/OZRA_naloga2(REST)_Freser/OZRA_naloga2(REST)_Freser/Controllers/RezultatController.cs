﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OZRA_naloga2_REST__Freser.Models;
using OZRA_naloga2_REST__Freser.Repositorys;

namespace OZRA_naloga2_REST__Freser.Controllers
{
    [Route("api/[controller]")]
    public class RezultatController : Controller
    {
        public IRezultatRepository grupa { get; set; }
        public OZRATriatlonDBContext db { get; set; }
        public RezultatController([FromServices] IRezultatRepository rep)
        {
            grupa = rep;
            db = new();
        }


        // GET: api/Rezultat
        [HttpGet]
        public IEnumerable<Rezultat> GetAll()
        {
            return grupa.GetAll();
        }

        // GET: api/Rezultat/{id}
        [HttpGet("{id}", Name = "GetRezultat")]
        public ActionResult Get(int id)
        {
            Rezultat iskan = grupa.GetRezultat(id);
            if (iskan == null)
                return NotFound("Rezultat s tem ključem ne obstaja.");

            return new ObjectResult(iskan);
        }

        // GET: api/Rezultat/tekac/{id}
        [HttpGet("tekac/{id}", Name = "GetRezultatTekmovalec")]
        public IEnumerable<Rezultat> GetResultsTekmovalec(int id)
        {
            IEnumerable<Rezultat> iskani = db.Rezultati.Where(x => x.TekmovalecId == id);
            
            
            return iskani;
        }

        // GET: api/Rezultat/tekac/{id}
        [HttpGet("tekma/{id}", Name = "GetRezultatTekmovanje")]
        public IEnumerable<Rezultat> GetResultsTekmovanje(int id)
        {
            IEnumerable<Rezultat> iskani = db.Rezultati.Where(x => x.TekmovanjeId == id);


            return iskani;
        }

        // POST: api/Rezultat
        [HttpPost]
        public ActionResult Create([FromBody] Rezultat rezultat)
        {
            if (rezultat == null)
                return BadRequest("Objekt \"rezultat\" ne obstaja");

            if(grupa.AddRezultat(rezultat))
                return CreatedAtRoute("GetRezultat", new {id = rezultat.Id}, rezultat);
            else
                return NoContent();
        }

        // PUT: api/Rezultat/{id}
        //[HttpPut("{id}", Name = "UpdateRezultat")]                          // TUKAJ JE PREJ BILO UPDATETEKMOVANJE
        [HttpPut]
        public ActionResult Update([FromBody]Rezultat rezultat)
        {
            if (rezultat == null)
                return BadRequest("Ključa nista enaka!");

            Rezultat stari = grupa.GetRezultat(rezultat.Id);
            if (stari == null)
                return NotFound("Rezultat s tem ključem ne obstaja.");
            else
            {
                grupa.Update(rezultat);
                return NoContent();
            }
        }

        // GET: api/Rezultat/{id}
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            if (id <= 0)
                return BadRequest("Ključ ni veljaven.");

            if (grupa.GetRezultat(id) == null)
                return NotFound("Rezultat s tem ključem ne obstaja.");
            else
            {
                grupa.Delete(id);
                return NoContent();
            }
        }





    }
}
