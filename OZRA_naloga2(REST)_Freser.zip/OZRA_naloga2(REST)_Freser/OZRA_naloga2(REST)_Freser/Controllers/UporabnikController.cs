﻿using Microsoft.AspNetCore.Mvc;
using OZRA_naloga2_REST__Freser.Models;
using OZRA_naloga2_REST__Freser.Repositorys;

namespace OZRA_naloga2_REST__Freser.Controllers
{
    [Route("api/[controller]")]
    public class UporabnikController : Controller
    {
        public IUporabnikRepository grupa { get; set; }
        public UporabnikController([FromServices] IUporabnikRepository rep)
        {
            grupa = rep;
        }


        // GET: api/Uporabnik
        [HttpGet]
        public IEnumerable<Uporabnik> GetAll()
        {
            return grupa.GetAll();
        }

        // GET: api/Uporabnik/asc
        [HttpGet("asc")]
        public IEnumerable<Uporabnik> GetAllAsc()
        {
            return grupa.GetAllAsc();
        }

        // GET: api/Uporabnik/desc
        [HttpGet("desc")]
        public IEnumerable<Uporabnik> GetAllDesc()
        {
            return grupa.GetAllDesc();
        }

        // GET: api/Uporabnik/{id}
        [HttpGet("{id}", Name = "GetUporabnik")]
        public ActionResult Get(int id)
        {
            Uporabnik iskan = grupa.GetUporabnik(id);
            if (iskan == null)
                return NotFound("Uporabnik s tem ključem ne obstaja.");

            return new ObjectResult(iskan);
        }

        // POST: api/Uporabnik
        [HttpPost]
        public ActionResult Create([FromBody] Uporabnik uporabnik)
        {
            if (uporabnik == null)
                return BadRequest("Objekt \"uporabnik\" ne obstaja");

            if (grupa.AddUporabnik(uporabnik))
                return CreatedAtRoute("GetUporabnik", new { id = uporabnik.Id }, uporabnik);
            else
                return NoContent();
        }

        //// PUT: api/Uporabnik/{id}
        //[HttpPut("{id}", Name = "UpdateTekmovanje")]
        //public ActionResult Update(int id, [FromBody] Uporabnik uporabnik)
        //{
        //    if (uporabnik == null)
        //        return BadRequest("Ključa nista enaka!");

        //    if (grupa.GetUporabnik(id) == null)
        //        return NotFound("Uporabnik s tem ključem ne obstaja.");
        //    else
        //    {
        //        grupa.Update(id, uporabnik);
        //        return NoContent();
        //    }
        //}

        // PUT: api/Uporabnik
        [HttpPut]
        public ActionResult Update([FromBody] Uporabnik uporabnik)
        {
            if (uporabnik == null)
                return BadRequest("Ključa nista enaka!");

            Uporabnik stari = grupa.GetUporabnik(uporabnik.Id);
            if (stari == null)
                return NotFound("Uporabnik s tem ključem ne obstaja!");
            else
            {
                grupa.Update(uporabnik);
                return NoContent();
            }
        }

        // GET: api/Uporabnik/{id}
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            if (id <= 0)
                return BadRequest("Ključ ni veljaven.");

            if (grupa.GetUporabnik(id) == null)
                return NotFound("Uporabnik s tem ključem ne obstaja.");
            else
            {
                grupa.Delete(id);
                return NoContent();
            }
        }
    }
}
