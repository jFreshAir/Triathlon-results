﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OZRA_naloga2_REST__Freser.Models;
using OZRA_naloga2_REST__Freser.Repositorys;

namespace OZRA_naloga2_REST__Freser.Controllers
{
    [Route("api/[controller]")]
    public class TekmovanjeController : Controller
    {
        public ITekmovanjeRepository tekma { get; set; }
        public TekmovanjeController([FromServices] ITekmovanjeRepository tek)
        {
            tekma = tek;
        }

        // GET: api/Tekmovanje
        [HttpGet]
        public IEnumerable<Tekmovanje> GetAll()
        {
            return tekma.GetAll();
        }

        // GET: api/Tekmovanje//stara
        [HttpGet("stara")]
        public IEnumerable<Tekmovanje> GetAllOlder()
        {
            return tekma.GetByDateOlder();
        }

        // GET: api/Tekmovanje/nova
        [HttpGet(("nova"))]
        public IEnumerable<Tekmovanje> GetAllNewer()
        {
            return tekma.GetByDateNewer();
        }

        // GET: api/Tekmovanje/{id}
        [HttpGet("{id}", Name = "GetTekmovanje")]
        public ActionResult Get(int id)
        {
            Tekmovanje iskano = tekma.GetTekmovanje(id);
            if(iskano == null)
                return NotFound("Tekmovanje s tem ključem ne obstaja.");

            return new ObjectResult(iskano);
        }

        // POST: api/Tekmovanje
        [HttpPost]
        public ActionResult Create([FromBody] Tekmovanje tekmovanje)
        {
            if (tekmovanje == null)
                return BadRequest();

            bool uspesno =  tekma.AddTekmovanje(tekmovanje);
            if(uspesno)
                return CreatedAtRoute("GetTekmovanje", new { id = tekmovanje.Id }, tekmovanje);
            else
                return NoContent();
        }

        // PUT: api/Tekmovanje/{id}
        //[HttpPut("{id}")]
        [HttpPut]
        public ActionResult Update([FromBody] Tekmovanje tekmovanje)
        {
            if (tekmovanje == null)
                return BadRequest("Ni podatkov!");

            Tekmovanje staro = tekma.GetTekmovanje(tekmovanje.Id);
            if (staro == null)
                return NotFound("Tekmovanje s tem ključem ne obstaja!");
            else
            {
                tekma.Update(tekmovanje);
                return NoContent();
            }
        }
        //[HttpPut("{id}")]
        //public ActionResult Update(int id, [FromBody] Tekmovanje tekmovanje)
        //{
        //    if (tekmovanje == null || tekmovanje.Id != id)
        //        return BadRequest("Ključa nista enaka!");

        //    Tekmovanje staro = tekma.GetTekmovanje(id);
        //    if(staro == null)
        //        return NotFound("Tekmovanje s tem ključem ne obstaja!");
        //    else
        //    {
        //        tekma.Update(id, tekmovanje);
        //        return NoContent();
        //    }
        //}

        // DELETE: api/Tekmovalec/{id}
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            if (id <= 0)
                return BadRequest("Ključ ni veljaven.");

            Tekmovanje staro = tekma.GetTekmovanje(id);
            if (staro == null)
                return NotFound("Tekmovanje s tem ključem ne obstaja.");
            else
            {
                tekma.Delete(id);
                return NoContent();
            }


        }

    }
}
