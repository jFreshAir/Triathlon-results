﻿using System;
using System.Collections.Generic;

namespace OZRA_naloga2_REST__Freser.Models
{
    public partial class Uporabnik
    {
        public int Id { get; set; }
        public string UporabniskoIme { get; set; } = null!;
        public string Geslo { get; set; } = null!;
        public bool Admin { get; set; }
    }
}
