﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
using Microsoft.EntityFrameworkCore;

namespace OZRA_naloga2_REST__Freser.Models
{
    [Table("Tekmovalci")]
    public partial class Tekmovalec
    {
        public Tekmovalec()
        {
            Rezultati = new HashSet<Rezultat>();
        }

        [Key]
        public int Id { get; set; }
        public string? Ime { get; set; }

        [JsonIgnore]
        [InverseProperty("Tekmovalec")]
        public virtual ICollection<Rezultat> Rezultati { get; set; }
    }
}
