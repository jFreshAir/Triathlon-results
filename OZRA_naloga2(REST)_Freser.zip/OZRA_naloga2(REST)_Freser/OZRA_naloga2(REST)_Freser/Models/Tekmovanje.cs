﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
using Microsoft.EntityFrameworkCore;

namespace OZRA_naloga2_REST__Freser.Models
{
    [Table("Tekmovanja")]
    public partial class Tekmovanje
    {
        public Tekmovanje()
        {
            Rezultati = new HashSet<Rezultat>();
        }

        [Key]
        public int Id { get; set; }
        public string? Ime { get; set; }
        public int? Leto { get; set; }

        [JsonIgnore]
        [InverseProperty("Tekmovanje")]
        public virtual ICollection<Rezultat> Rezultati { get; set; }
    }
}
