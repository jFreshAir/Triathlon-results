﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace OZRA_naloga2_REST__Freser.Models
{
    public partial class OZRATriatlonDBContext : DbContext
    {
        public OZRATriatlonDBContext()
        {
        }

        public OZRATriatlonDBContext(DbContextOptions<OZRATriatlonDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Rezultat> Rezultati { get; set; } = null!;
        public virtual DbSet<Tekmovalec> Tekmovalci { get; set; } = null!;
        public virtual DbSet<Tekmovanje> Tekmovanja { get; set; } = null!;
        public virtual DbSet<Uporabnik> Uporabniki { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=OZRA.TriatlonDB;Trusted_Connection=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Rezultat>(entity =>
            {
                entity.ToTable("Rezultati");

                entity.HasIndex(e => e.TekmovalecId, "IX_Rezultati_TekmovalecId");

                entity.HasIndex(e => e.TekmovanjeId, "IX_Rezultati_TekmovanjeId");

                entity.Property(e => e.UvrstitevVspolu).HasColumnName("UvrstitevVSpolu");

                entity.Property(e => e.UvrstitevVstarKat).HasColumnName("UvrstitevVStarKat");

                entity.HasOne(d => d.Tekmovalec)
                    .WithMany(p => p.Rezultati)
                    .HasForeignKey(d => d.TekmovalecId);

                entity.HasOne(d => d.Tekmovanje)
                    .WithMany(p => p.Rezultati)
                    .HasForeignKey(d => d.TekmovanjeId);
            });

            modelBuilder.Entity<Tekmovalec>(entity =>
            {
                entity.ToTable("Tekmovalci");
            });

            modelBuilder.Entity<Tekmovanje>(entity =>
            {
                entity.ToTable("Tekmovanja");
            });

            modelBuilder.Entity<Uporabnik>(entity =>
            {
                entity.ToTable("Uporabniki");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
