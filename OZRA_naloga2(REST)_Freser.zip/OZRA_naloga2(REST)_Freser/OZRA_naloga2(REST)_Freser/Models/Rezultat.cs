﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
using Microsoft.EntityFrameworkCore;

namespace OZRA_naloga2_REST__Freser.Models
{
    [Table("Rezultati")]
    [Index("TekmovalecId", Name = "IX_Rezultat_TekmovalecId")]
    [Index("TekmovanjeId", Name = "IX_Rezultat_TekmovanjeId")]
    public partial class Rezultat
    {
        [Key]
        public int Id { get; set; }
        [Column("UvrstitevVSpolu")]
        public string? UvrstitevVspolu { get; set; }
        [Column("UvrstitevVStarKat")]
        public string? UvrstitevVstarKat { get; set; }
        public string? KoncnaUvrstitev { get; set; }
        public string? StartnaSt { get; set; }
        public string? Kategorija { get; set; }
        public string? Starost { get; set; }
        public string? KrajT { get; set; }
        public string? DrzavaT { get; set; }
        public string? Poklic { get; set; }
        public string? Tocke { get; set; }
        public string? CasPlavanje { get; set; }
        public string? DolzinaPlavanje { get; set; }
        public string? Tranzicija1 { get; set; }
        public string? CasKolo { get; set; }
        public string? DolzinaKolo { get; set; }
        public string? Tranzicija2 { get; set; }
        public string? CasTek { get; set; }
        public string? DolzinaTek { get; set; }
        public string? SkupniCas { get; set; }
        public int? TekmovalecId { get; set; }
        public int? TekmovanjeId { get; set; }

        [JsonIgnore]
        [ForeignKey("TekmovalecId")]
        [InverseProperty("Rezultati")]
        public virtual Tekmovalec? Tekmovalec { get; set; }

        [JsonIgnore]
        [ForeignKey("TekmovanjeId")]
        [InverseProperty("Rezultati")]
        public virtual Tekmovanje? Tekmovanje { get; set; }
    }
}
