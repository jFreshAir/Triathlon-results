﻿using OZRA_naloga2_REST__Freser.Models;

namespace OZRA_naloga2_REST__Freser
{
    public class PoslovnaLogika
    {
        public OZRATriatlonDBContext db;
        public PoslovnaLogika()
        {
            db = new OZRATriatlonDBContext();
        }

        #region TEKMOVANJA
        //      TEKMOVANJA

        public IEnumerable<Tekmovanje> AllTekmovanja()
        {
             return db.Tekmovanja.ToList();  
        }

        public IEnumerable<Tekmovanje> AllTekmovanjaNewer()
        {
          
            return db.Tekmovanja.OrderByDescending(x => x.Leto);

            
        }

        public IEnumerable<Tekmovanje> AllTekmovanjaOlder()
        {
            
                return db.Tekmovanja.OrderBy(x => x.Leto);
            
        }

        public Tekmovanje Tekmovanje(int id)
        {
            
                return db.Tekmovanja.FirstOrDefault(t => t.Id == id);
            
        }

        public bool DodajTekmovanje(Tekmovanje tekmovanje)
        {
            
                db.Tekmovanja.Add(tekmovanje);
                db.SaveChanges();
                return db.Tekmovanja.Where(x => x.Id == tekmovanje.Id) == tekmovanje;
            
        }

        public bool PosodobiTekmovanje(Tekmovanje tekmovanje)
        {
            
                Tekmovanje staro = db.Tekmovanja.FirstOrDefault(t => t.Id == tekmovanje.Id);

                if (staro == null)
                    return false;

                staro.Ime = tekmovanje.Ime;
                staro.Leto = tekmovanje.Leto;

                db.SaveChanges();

                return true;
            
        }

        public Tekmovanje IzbrisiTekmovanje(int id)
        {
            
                Tekmovanje zaIzbris = db.Tekmovanja.FirstOrDefault(t => t.Id == id);
                db.Tekmovanja.Remove(zaIzbris);
                db.SaveChanges();

                return zaIzbris;
            
        }
        #endregion



        #region TEKMOVALCI
        //      TEKMOVALCI

        public IEnumerable<Tekmovalec> AllTekmovalci()
        {
            
                return db.Tekmovalci.ToList();
            
        }

        public IEnumerable<Tekmovalec> BestTekmovalci()
        {
            return db.Tekmovalci.Where(x => x.Rezultati.Any(r => r.KoncnaUvrstitev == "1"));
        }

        public IEnumerable<Tekmovalec> BestCatTekmovalci()
        {
            return db.Tekmovalci.Where(x => x.Rezultati.Any(r => r.UvrstitevVstarKat == "1"));
        }

        public IEnumerable<Tekmovalec> BestGenTekmovalci()
        {
            return db.Tekmovalci.Where(x => x.Rezultati.Any(r => r.UvrstitevVspolu == "1"));
        }

        public IEnumerable<Tekmovalec> AllTekmovalciASC()
        {
            
                return db.Tekmovalci.OrderBy(x => x.Ime);
            
        }

        public IEnumerable<Tekmovalec> AllTekmovalciDESC()
        {

            return db.Tekmovalci.OrderByDescending(x => x.Ime);

        }

        public IEnumerable<Tekmovalec> TekmovalciName(string name)
        {
            
                return db.Tekmovalci.Where(x => x.Ime.ToLower().Contains(name.ToLower()));
            
            //List<Tekmovalec> list = new List<Tekmovalec>();
            //list.Add(new Tekmovalec { Ime = "JOŽA PODLESNIK" });
            //return list;
        }


        public Tekmovalec Tekmovalec(int id)
        {
            
                return db.Tekmovalci.FirstOrDefault(t => t.Id == id);
            
        }

        public bool DodajTekmovalca(Tekmovalec tekmovalec)
        {
            
                db.Tekmovalci.Add(tekmovalec);
                db.SaveChanges();
                return db.Tekmovalci.Where(x => x.Id == tekmovalec.Id).Any();
            
        }

        public bool PosodobiTekmovalca(Tekmovalec tekmovalec)
        {
            
                Tekmovalec stari = db.Tekmovalci.FirstOrDefault(t => t.Id == tekmovalec.Id);

                if (stari == null)
                    return false;

                stari.Ime = tekmovalec.Ime;

                db.SaveChanges();

                return true;
            
        }

        public Tekmovalec IzbrisiTekmovalca(int id)
        {
            
                Tekmovalec zaIzbris = db.Tekmovalci.FirstOrDefault(t => t.Id == id);
                db.Tekmovalci.Remove(zaIzbris);
                db.SaveChanges();

                return zaIzbris;
            
        }
        #endregion



        #region REZULTATI
        //      REZULTATI


        public IEnumerable<Rezultat> AllRezultati()
        {
            
                return db.Rezultati.ToList();
            
        }

        public Rezultat Rezultat(int id)
        {
            
                return db.Rezultati.FirstOrDefault(t => t.Id == id);
            
        }

        public bool DodajRezultat(Rezultat rezultat)
        {
            
                db.Rezultati.Add(rezultat);
                db.SaveChanges();
                return db.Rezultati.Where(x => x.Id == rezultat.Id).Any();
            
        }

        public bool PosodobiRezultat(Rezultat rezultat)
        {
            
                Rezultat stari = db.Rezultati.FirstOrDefault(t => t.Id == rezultat.Id);

                if (stari == null)
                    return false;

                stari.UvrstitevVspolu = rezultat.UvrstitevVspolu;
                stari.UvrstitevVstarKat = rezultat.UvrstitevVstarKat;
                stari.KoncnaUvrstitev = rezultat.KoncnaUvrstitev;
                stari.StartnaSt = rezultat.StartnaSt;
                stari.Kategorija = rezultat.Kategorija;
                stari.Starost = rezultat.Starost;
                stari.KrajT = rezultat.KrajT;
                stari.DrzavaT = rezultat.DrzavaT;
                stari.Poklic = rezultat.Poklic;
                stari.Tocke = rezultat.Tocke;
                stari.CasPlavanje = rezultat.CasPlavanje;
                stari.DolzinaPlavanje = rezultat.DolzinaPlavanje;
                stari.Tranzicija1 = rezultat.Tranzicija1;
                stari.CasKolo = rezultat.CasKolo;
                stari.DolzinaKolo = rezultat.DolzinaKolo;
                stari.Tranzicija2 = rezultat.Tranzicija2;
                stari.CasTek = rezultat.CasTek;
                stari.DolzinaTek = rezultat.DolzinaTek;
                stari.SkupniCas = rezultat.SkupniCas;

                //  tekmovalec tekmovanje ??

                db.SaveChanges();

                return true;
            
        }

        public Rezultat IzbrisiRezultat(int id)
        {
            
                Rezultat zaIzbris = db.Rezultati.FirstOrDefault(t => t.Id == id);
                db.Rezultati.Remove(zaIzbris);
                db.SaveChanges();

                return zaIzbris;
            
        }
        #endregion

        #region UPORABNIKI
        //      UPORABNIKI

        public IEnumerable<Uporabnik> GetAll()
        {
            
                return db.Uporabniki.ToList();
            
        }

        public IEnumerable<Uporabnik> GetAllAsc()
        {

            return db.Uporabniki.OrderBy(x => x.UporabniskoIme);

        }

        public IEnumerable<Uporabnik> GetAllDesc()
        {

            return db.Uporabniki.OrderByDescending(x => x.UporabniskoIme);

        }

        public Uporabnik Uporabnik(int id)
        {
                return db.Uporabniki.FirstOrDefault(x => x.Id == id);
            
        }

        public bool DodajUporabnika(Uporabnik uporabnik)
        {
            
                db.Uporabniki.Add(uporabnik);
                db.SaveChanges();

                return db.Uporabniki.Any(x => x.Id == uporabnik.Id);
            
        }

        public bool PosodobiUporabnika(Uporabnik uporabnik)
        {
            
                Uporabnik iskan = db.Uporabniki.FirstOrDefault(x => x.Id == uporabnik.Id);

                if (iskan == null)
                    return false;

                iskan.UporabniskoIme = uporabnik.UporabniskoIme;
                iskan.Geslo = uporabnik.Geslo;
                iskan.Admin = uporabnik.Admin;

                db.SaveChanges();

                return true;
            
        }

        public bool PosodobiUporabnika(int id, bool admin)
        {
            
                Uporabnik iskan = db.Uporabniki.FirstOrDefault(x => x.Id == id);

                if (iskan == null)
                    return false;

                iskan.Admin = admin;

                db.SaveChanges();

                return true;
            
        }

        public Uporabnik IzbrisiUporabnika(int id)
        {
           
                Uporabnik izbris =  db.Uporabniki.FirstOrDefault(x =>x.Id == id);
                db.Uporabniki.Remove(izbris);
                db.SaveChanges();

                return izbris;
             
        }



    #endregion

    }
}
