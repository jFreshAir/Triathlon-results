﻿using OZRA_naloga2_REST__Freser.Models;

namespace OZRA_naloga2_REST__Freser.Repositorys
{
    public class TekmovalecRepository : ITekmovalecRepository
    {

        public PoslovnaLogika logika;
        public TekmovalecRepository()
        {
            logika = new PoslovnaLogika();
        }
        public bool AddTekmovalca(Tekmovalec tekmovalec)
        {
            return logika.DodajTekmovalca(tekmovalec);
        }

        public Tekmovalec Delete(int id)
        {
            return logika.IzbrisiTekmovalca(id);
        }

        public IEnumerable<Tekmovalec> GetAll()
        {
            return logika.AllTekmovalci();
        }

        public IEnumerable<Tekmovalec> GetBest()
        {
            return logika.BestTekmovalci();
        }

        public IEnumerable<Tekmovalec> GetBestCat()
        {
            return logika.BestCatTekmovalci();
        }

        public IEnumerable<Tekmovalec> GetBestGen()
        {
            return logika.BestGenTekmovalci();
        }

        public Tekmovalec GetTekmovalec(int id)
        {
            return logika.Tekmovalec(id);
        }

        public bool Update(Tekmovalec tekmovalec)
        {
            return logika.PosodobiTekmovalca(tekmovalec);
        }



        public IEnumerable<Tekmovalec> GetAllAsc()
        {
            return logika.AllTekmovalciASC();
        }

        public IEnumerable<Tekmovalec> GetAllDesc()
        {
            return logika.AllTekmovalciDESC();
        }

        public IEnumerable<Tekmovalec> GetByName(string name)
        {
            return logika.TekmovalciName(name);
        }
    }
}
