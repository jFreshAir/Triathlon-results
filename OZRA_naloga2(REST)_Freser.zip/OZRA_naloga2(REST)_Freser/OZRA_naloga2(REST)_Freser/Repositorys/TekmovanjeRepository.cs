﻿namespace OZRA_naloga2_REST__Freser.Models
{
    public class TekmovanjeRepository : ITekmovanjeRepository
    {
        public PoslovnaLogika logika;
        public TekmovanjeRepository()
        {
            logika = new PoslovnaLogika();
        }

        public bool AddTekmovanje(Tekmovanje tekmovanje)
        {
            return logika.DodajTekmovanje(tekmovanje);
        }

        public Tekmovanje Delete(int id)
        {
            return logika.IzbrisiTekmovanje(id);
        }

        public IEnumerable<Tekmovanje> GetAll()
        {
            return logika.AllTekmovanja();
        }

        public Tekmovanje GetTekmovanje(int id)
        {
            return logika.Tekmovanje(id);
        }

        public bool Update(Tekmovanje tekmovanje)
        {
            return logika.PosodobiTekmovanje(tekmovanje);
        }

        

        public IEnumerable<Tekmovanje> GetByDateNewer()
        {
            return logika.AllTekmovanjaNewer();
        }

        public IEnumerable<Tekmovanje> GetByDateOlder()
        {
            return logika.AllTekmovanjaOlder();
        }
    }
}
