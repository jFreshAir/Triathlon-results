﻿using OZRA_naloga2_REST__Freser.Models;

namespace OZRA_naloga2_REST__Freser.Repositorys
{
    public interface IUporabnikRepository
    {
        IEnumerable<Uporabnik> GetAll();
        IEnumerable<Uporabnik> GetAllAsc();
        IEnumerable<Uporabnik> GetAllDesc();
        Uporabnik GetUporabnik(int id);
        bool AddUporabnik(Uporabnik uporabnik);
        bool Update(Uporabnik uporabnik);
        bool Update(int id, bool admin);
        Uporabnik Delete(int id);
    }
}
