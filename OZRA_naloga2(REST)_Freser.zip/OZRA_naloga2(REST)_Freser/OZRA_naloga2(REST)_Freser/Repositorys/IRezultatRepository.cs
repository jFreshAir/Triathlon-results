﻿using OZRA_naloga2_REST__Freser.Models;

namespace OZRA_naloga2_REST__Freser.Repositorys
{
    public interface IRezultatRepository
    {
        IEnumerable<Rezultat> GetAll();
        Rezultat GetRezultat(int id);
        bool AddRezultat(Rezultat rezultat);
        bool Update(Rezultat rezultat);
        Rezultat Delete(int id);

    }
}
