﻿namespace OZRA_naloga2_REST__Freser.Models
{
    public interface ITekmovanjeRepository
    {
        IEnumerable<Tekmovanje> GetAll();
        Tekmovanje GetTekmovanje(int id);
        bool AddTekmovanje(Tekmovanje tekmovanje);
        bool Update(Tekmovanje tekmovanje);
        Tekmovanje Delete(int id);


        IEnumerable<Tekmovanje> GetByDateNewer();
        IEnumerable<Tekmovanje> GetByDateOlder();
    }
}
