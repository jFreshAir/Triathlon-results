﻿using OZRA_naloga2_REST__Freser.Models;

namespace OZRA_naloga2_REST__Freser.Repositorys
{
    public class RezultatRepository : IRezultatRepository
    {
        public PoslovnaLogika logika;
        public RezultatRepository()
        {
            logika = new PoslovnaLogika();
        }
        public bool AddRezultat(Rezultat rezultat)
        {
            return logika.DodajRezultat(rezultat);
        }

        public Rezultat Delete(int id)
        {
            return logika.IzbrisiRezultat(id);
        }

        public IEnumerable<Rezultat> GetAll()
        {
            return logika.AllRezultati();
        }

        public Rezultat GetRezultat(int id)
        {
            return logika.Rezultat(id);
        }

        public bool Update(Rezultat rezultat)
        {
            return logika.PosodobiRezultat(rezultat);
        }
    }
}
