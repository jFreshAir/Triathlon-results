﻿using OZRA_naloga2_REST__Freser.Models;

namespace OZRA_naloga2_REST__Freser.Repositorys
{
    public class UporabnikRepository : IUporabnikRepository
    {

        private PoslovnaLogika logika;

        public UporabnikRepository()
        {
            logika = new();
        }

        public bool AddUporabnik(Uporabnik uporabnik)
        {
            return logika.DodajUporabnika(uporabnik);
        }

        public Uporabnik Delete(int id)
        {
            return logika.IzbrisiUporabnika(id);
        }

        public IEnumerable<Uporabnik> GetAll()
        {
            return logika.GetAll();
        }

        public IEnumerable<Uporabnik> GetAllAsc()
        {
            return logika.GetAllAsc();
        }

        public IEnumerable<Uporabnik> GetAllDesc()
        {
            return logika.GetAllDesc();
        }

        public Uporabnik GetUporabnik(int id)
        {
            return logika.Uporabnik(id);
        }

        public bool Update(Uporabnik uporabnik)
        {
            return logika.PosodobiUporabnika(uporabnik);
        }

        public bool Update(int id, bool admin)
        {
            return logika.PosodobiUporabnika(id, admin);
        }
    }
}
