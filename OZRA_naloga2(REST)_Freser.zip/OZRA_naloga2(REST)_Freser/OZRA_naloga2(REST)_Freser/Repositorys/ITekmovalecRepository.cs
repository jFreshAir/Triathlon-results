﻿using OZRA_naloga2_REST__Freser.Models;

namespace OZRA_naloga2_REST__Freser.Repositorys
{
    public interface ITekmovalecRepository
    {
        IEnumerable<Tekmovalec> GetAll();
        IEnumerable<Tekmovalec> GetBest();
        IEnumerable<Tekmovalec> GetBestCat();
        IEnumerable<Tekmovalec> GetBestGen();
        Tekmovalec GetTekmovalec(int id);
        bool AddTekmovalca(Tekmovalec tekmovalec);
        bool Update(Tekmovalec tekmovalec);
        Tekmovalec Delete(int id);

        IEnumerable<Tekmovalec> GetAllAsc();
        IEnumerable<Tekmovalec> GetAllDesc();
        IEnumerable<Tekmovalec> GetByName(string name);
    }
}










