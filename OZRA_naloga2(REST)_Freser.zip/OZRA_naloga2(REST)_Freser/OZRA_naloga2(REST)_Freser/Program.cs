using Microsoft.EntityFrameworkCore;
using OZRA_naloga2_REST__Freser.Models;
using OZRA_naloga2_REST__Freser.Repositorys;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();

builder.Services.AddDbContext<OZRATriatlonDBContext>(op => op.UseSqlServer(builder.Configuration.GetConnectionString("Database")));

builder.Services.AddSingleton<ITekmovanjeRepository, TekmovanjeRepository>();
builder.Services.AddSingleton<ITekmovalecRepository, TekmovalecRepository>();
builder.Services.AddSingleton<IRezultatRepository, RezultatRepository>();
builder.Services.AddSingleton<IUporabnikRepository, UporabnikRepository>();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
//builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    //app.UseSwagger();
    //app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
