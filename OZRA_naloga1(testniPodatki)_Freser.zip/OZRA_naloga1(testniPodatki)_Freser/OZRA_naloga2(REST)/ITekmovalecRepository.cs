﻿using OZRA_naloga1_testniPodatki__Freser.Razredi;

namespace OZRA_naloga2_REST_
{
    public interface ITekmovalecRepository
    {
        bool PostTekmovalec(Tekmovalec tekmovalec);
        IEnumerable<Tekmovalec> GetAllTekmovalci();
        Tekmovalec GetTekmovalec(string kljuc);
        Tekmovalec DeleteTekmovalec(string kljuc);
        bool Put(string kljuc, Tekmovalec tekmovalec);


    }
}
