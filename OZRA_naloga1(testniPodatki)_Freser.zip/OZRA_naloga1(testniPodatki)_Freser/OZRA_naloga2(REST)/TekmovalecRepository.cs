﻿using OZRA_naloga1_testniPodatki__Freser.Razredi;
using OZRA_naloga1_testniPodatki__Freser;

namespace OZRA_naloga2_REST_
{
    public class TekmovalecRepository : ITekmovalecRepository
    {
        // bool namesto tekmovalec?
        public Tekmovalec DeleteTekmovalec(string kljuc)
        {
            using (var db = new TriatlonDbContext())
            {
                Tekmovalec iskan = db.Tekmovalci.FirstOrDefault(x => x.Id == int.Parse(kljuc));
                db.Tekmovalci.Remove(iskan);
                return iskan;
            }
        }

        public IEnumerable<Tekmovalec> GetAllTekmovalci()
        {
            using (var db = new TriatlonDbContext())
            {   
                return db.Tekmovalci.ToList<Tekmovalec>();
            }
        }

        public Tekmovalec GetTekmovalec(string kljuc)
        {
            using(var db = new TriatlonDbContext())
            {
                Tekmovalec iskan = db.Tekmovalci.FirstOrDefault(x => x.Id == int.Parse(kljuc));
                return iskan;
            }
        }

        public bool PostTekmovalec(Tekmovalec tekmovalec)
        {
            using (var db = new TriatlonDbContext())
            {
                db.Tekmovalci.Add(tekmovalec);
                return db.Tekmovalci.ElementAt(tekmovalec.Id) == tekmovalec;
            }
        }

        public bool Put(string kljuc, Tekmovalec tekmovalec)
        {
            throw new NotImplementedException();
        }
    }
}
