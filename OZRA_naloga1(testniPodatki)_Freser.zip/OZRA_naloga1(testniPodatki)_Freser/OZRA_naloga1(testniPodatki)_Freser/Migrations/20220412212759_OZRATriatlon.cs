﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OZRA_naloga1_testniPodatki__Freser.Migrations
{
    public partial class OZRATriatlon : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Tekmovalci",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Ime = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tekmovalci", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tekmovanja",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Ime = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Leto = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tekmovanja", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Rezultati",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UvrstitevVSpolu = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UvrstitevVStarKat = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    KoncnaUvrstitev = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StartnaSt = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Kategorija = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Starost = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    KrajT = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DrzavaT = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Poklic = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Tocke = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CasPlavanje = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DolzinaPlavanje = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Tranzicija1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CasKolo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DolzinaKolo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Tranzicija2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CasTek = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DolzinaTek = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SkupniCas = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TekmovalecId = table.Column<int>(type: "int", nullable: true),
                    TekmovanjeId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Rezultati", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Rezultati_Tekmovalci_TekmovalecId",
                        column: x => x.TekmovalecId,
                        principalTable: "Tekmovalci",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Rezultati_Tekmovanja_TekmovanjeId",
                        column: x => x.TekmovanjeId,
                        principalTable: "Tekmovanja",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Rezultati_TekmovalecId",
                table: "Rezultati",
                column: "TekmovalecId");

            migrationBuilder.CreateIndex(
                name: "IX_Rezultati_TekmovanjeId",
                table: "Rezultati",
                column: "TekmovanjeId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Rezultati");

            migrationBuilder.DropTable(
                name: "Tekmovalci");

            migrationBuilder.DropTable(
                name: "Tekmovanja");
        }
    }
}
