﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using OZRA_naloga1_testniPodatki__Freser.Razredi;

namespace OZRA_naloga1_testniPodatki__Freser
{
    public class TriatlonDbContext : DbContext
    {
        public DbSet<Tekmovalec> Tekmovalci { get; set; }
        public DbSet<Tekmovanje> Tekmovanja { get; set; }
        public DbSet<Rezultat> Rezultati { get; set; }
        public DbSet<Uporabnik> Uporabniki { get; set; }
 
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=(localdb)\mssqllocaldb;Database=OZRA.TriatlonDB;Trusted_Connection=True");
        }
    }
}
