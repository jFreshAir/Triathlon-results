﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace OZRA_naloga1_testniPodatki__Freser.Razredi
{
    public class Rezultat
    {
        [Required]
        [Key]
        public int Id { get; set; }
        public string? UvrstitevVSpolu { get; set; }
        public string? UvrstitevVStarKat { get; set; }
        public string? KoncnaUvrstitev { get; set; }
        public string? StartnaSt { get; set; }
        public string? Kategorija { get; set; }
        public string? Starost { get; set; }
        public string? KrajT { get; set; }
        public string? DrzavaT { get; set; }
        public string? Poklic { get; set; }
        public string? Tocke { get; set; }
        public string? CasPlavanje { get; set; }
        public string? DolzinaPlavanje { get; set; }
        public string? Tranzicija1 { get; set; }
        public string? CasKolo { get; set; }
        public string? DolzinaKolo { get; set; }
        public string? Tranzicija2 { get; set; }
        public string? CasTek { get; set; }
        public string? DolzinaTek { get; set; }
        public string? SkupniCas { get; set; }
        public Tekmovalec Tekmovalec { get; set; }
        public Tekmovanje Tekmovanje { get; set; }

        //      ZA ULTRA-TRIATLON
    }
}
