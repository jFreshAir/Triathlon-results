﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace OZRA_naloga1_testniPodatki__Freser.Razredi
{
    public class Tekmovalec
    {
        [Required]
        [Key]
        public int Id { get; set; }
        public string Ime { get; set; }
        public ICollection<Rezultat> Rezultati { get; set; }

        public Tekmovalec(int id, string ime, ICollection<Rezultat> dosezki)
        {
            Id = id;
            Ime = ime;
            Rezultati = dosezki;
        }

        public Tekmovalec()
        {
            Rezultati = new List<Rezultat>();
        }
    }
}
