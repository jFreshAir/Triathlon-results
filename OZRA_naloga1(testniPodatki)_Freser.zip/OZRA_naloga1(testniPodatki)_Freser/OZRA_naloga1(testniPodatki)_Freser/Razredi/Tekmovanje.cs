﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace OZRA_naloga1_testniPodatki__Freser.Razredi
{
    public class Tekmovanje
    {
        [Required]
        [Key]
        public int Id { get; set; }
        public string Ime { get; set; }
        public int Leto { get; set; }
        public ICollection<Rezultat> Rezultati { get; set; }

        public Tekmovanje(int id, string ime, int leto)
        {
            Id = id;
            Ime = ime;
            Leto = leto;
            Rezultati = new List<Rezultat>();
        }

        public Tekmovanje()
        {
            Rezultati = new List<Rezultat>();
        }
    }
}
