﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OZRA_naloga1_testniPodatki__Freser.Razredi
{
    public class Uporabnik
    {
        [Required]
        [Key]
        public int Id { get; set; }
        public string UporabniskoIme { get; set; }
        public string Geslo { get; set; }
        public bool Admin { get; set; }
    }
}
