﻿using System;
using System.Diagnostics;
using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;
using OZRA_naloga1_testniPodatki__Freser.Razredi;

namespace OZRA_naloga1_testniPodatki__Freser
{
    public class Program
    {
        public static string missingStr(string podatek)
        {
            if (podatek == "---")
                return "EMPTY";
            else if (podatek == "--")
                return "EMPTY";
            else if (podatek == "-")
                return "EMPTY";
            else if (podatek == "0")
                return "EMPTY";
            else if (podatek == "")
                return "EMPTY";
            else if (podatek == " ")
                return "EMPTY";
            else
                return podatek;
        }
        public static int missingInt(string podatek)
        {
            if (podatek == "---")
                return -1;
            else if (podatek == "--")
                return -1;
            else if (podatek == "-")
                return -1;
            else if (podatek == "0")
                return -1;
            else if (podatek == "")
                return -1;
            else if (podatek == " ")
                return -1;
            else
                return int.Parse(podatek);
        }
        public static double missingDouble(string podatek)
        {
            if (podatek == "---")
                return -1;
            else if (podatek == "--")
                return -1;
            else if (podatek == "-")
                return -1;
            else if (podatek == "0")
                return -1;
            else if (podatek == "")
                return -1;
            else if (podatek == " ")
                return -1;
            else
                return double.Parse(podatek);
        }

        public static Tekmovanje Tekmovanje(string path, bool ultra)
        {
            string[] fullInfo = path.Split('\\');

            string[] info = fullInfo[fullInfo.Length-1].Split('_');

            Tekmovanje eno;
            if (!ultra)
            {
                if (info.Length == 3)
                {
                    string[] leto = info[2].Split('.');

                    eno = new Tekmovanje { Ime = info[0] + '_' + info[1], Leto = int.Parse(leto[0]) };
                }
                else
                {
                    string[] leto = info[3].Split('.');

                    eno = new Tekmovanje { Ime = info[0] + '_' + info[1] + '_' + info[2], Leto = int.Parse(leto[0]) };
                } 
            }
            else
            {
                if(info.Length == 4)
                {
                    string[] konec = info[3].Split('.');
                    string spol = konec[0];

                    eno = new Tekmovanje { Ime = info[0] + '_' + info[1] + '_' + spol, Leto = int.Parse(info[2]) };
                }
                else
                {
                    string[] konec = info[4].Split('.');
                    string spol = konec[0];

                    eno = new Tekmovanje { Ime = info[0] + '_' + info[1] + '_' + info[2] + '_' + spol, Leto = int.Parse(info[3]) };
                }
            }

            return eno;
        }

        public static List<Rezultat> Rezultati(string path, ref List<Tekmovalec> vsiTekmovalci, Tekmovanje tekmovanje, bool ultra)
        {
            List<Rezultat> vmesniRezultat = new List<Rezultat>();
            int count = 0;
            char loci = ',';
 
            string[] vseVrstice;
            string[] rezultatEneVrstice;
            string[] imenaStolpcev;

            
            if (File.Exists(path))
            {
                vseVrstice = File.ReadAllLines(path);
                foreach (string v in vseVrstice)
                {
                    //      PRIDOBIMO PODATKE O STOLPCIH
                    if (count == 0)
                    {
                        count++;
                        imenaStolpcev = v.Split(loci);
                        continue;
                    }

                    count++;

                    if (!ultra)
                    {
                        rezultatEneVrstice = v.Split(loci);

                        int a = 100;
                        //      PREVERIMO ČE TA TEKMOVALEC ŽE OBSTAJA
                        //Tekmovalec nov;
                        //Tekmovalec obstajaTekmovalec = vsiTekmovalci.FirstOrDefault(x => x.Ime.Contains(missingStr(rezultatEneVrstice[0])));

                        //if (obstajaTekmovalec != null)
                        //    nov = obstajaTekmovalec;
                        //else
                        //    nov = new Tekmovalec { Ime = missingStr(rezultatEneVrstice[0]) };


                        //      USTVARIMO TEKMOVALCA

                        try
                        {
                            Tekmovalec nov = new Tekmovalec { Ime = missingStr(rezultatEneVrstice[0]) };
                            vsiTekmovalci.Add(nov);

                            Rezultat novRezultat = new Rezultat
                            {
                                Tekmovanje = tekmovanje,
                                Tekmovalec = nov,
                                UvrstitevVSpolu = missingStr(rezultatEneVrstice[1]),
                                UvrstitevVStarKat = missingStr(rezultatEneVrstice[2]),
                                KoncnaUvrstitev = missingStr(rezultatEneVrstice[3]),
                                StartnaSt = missingStr(rezultatEneVrstice[4]),
                                Kategorija = missingStr(rezultatEneVrstice[5]),
                                Starost = missingStr(rezultatEneVrstice[6]),
                                KrajT = missingStr(rezultatEneVrstice[7]),
                                DrzavaT = missingStr(rezultatEneVrstice[8]),
                                Poklic = missingStr(rezultatEneVrstice[9]),
                                Tocke = missingStr(rezultatEneVrstice[10]),
                                CasPlavanje = missingStr(rezultatEneVrstice[11]),
                                DolzinaPlavanje = missingStr(rezultatEneVrstice[12]),
                                Tranzicija1 = missingStr(rezultatEneVrstice[13]),
                                CasKolo = missingStr(rezultatEneVrstice[14]),
                                DolzinaKolo = missingStr(rezultatEneVrstice[15]),
                                Tranzicija2 = missingStr(rezultatEneVrstice[16]),
                                CasTek = missingStr(rezultatEneVrstice[17]),
                                DolzinaTek = missingStr(rezultatEneVrstice[18]),
                                SkupniCas = missingStr(rezultatEneVrstice[19]),
                            };

                            nov.Rezultati.Add(novRezultat);
                            vmesniRezultat.Add(novRezultat);
                        }
                        catch (Exception)
                        { } 
                    }
                    else
                    {
                        Regex regx = new Regex(loci + "(?=(?:[^\"]*\"[^\"]*\")*(?![^\"]*\"))");
                        rezultatEneVrstice = regx.Split(v);

                        try
                        {
                            Tekmovalec nov = new Tekmovalec { Ime = missingStr(rezultatEneVrstice[2]) };
                            vsiTekmovalci.Add(nov);

                            Rezultat novRezultat = new Rezultat
                            {
                                Tekmovanje = tekmovanje,
                                Tekmovalec = nov,
                                UvrstitevVSpolu = missingStr(rezultatEneVrstice[0]), // RANK
                                KoncnaUvrstitev = missingStr(rezultatEneVrstice[1]), // OVERALL
                                Kategorija = missingStr(rezultatEneVrstice[3]), // AGE_CATEGORY
                                DrzavaT = missingStr(rezultatEneVrstice[4]), // COUNTRY
                                CasPlavanje = missingStr(rezultatEneVrstice[5]), // SWIM
                                Tranzicija1 = missingStr(rezultatEneVrstice[6]), // TRANS 1
                                CasKolo = missingStr(rezultatEneVrstice[7]), // BIKE
                                Tranzicija2 = missingStr(rezultatEneVrstice[8]), //TRANS 2
                                CasTek = missingStr(rezultatEneVrstice[9]),    // RUN
                                SkupniCas = missingStr(rezultatEneVrstice[10]), // FINISH
                            };

                            nov.Rezultati.Add(novRezultat);
                            vmesniRezultat.Add(novRezultat);
                        }
                        catch(Exception) { }
                    }

                }
            }
            
            return vmesniRezultat;
        }

        public static List<Tekmovanje> TekmovanjaEneMape(string path, ref List<Tekmovalec> vsiTekmovalci, ref List<Rezultat> vsiRezultati, bool ultra)
        {
            string fileType = "*.csv";
            List<string> fileNames = new List<string>();
            //List<string> tekmovanjaNames = new List<string>();
            List<Tekmovanje> tekmovanja = new List<Tekmovanje>();
            List<Rezultat> vmesniRezultati = new List<Rezultat>();

            //      POIŠČEMO MAPO IN VSA IMENA DATOTEK DODAMO V LIST

            try
            {
                DirectoryInfo mapa = new DirectoryInfo(path);
                FileInfo[] vseDatoteke = mapa.GetFiles(fileType);
                foreach (FileInfo f in vseDatoteke)
                {
                    //tekmovanjaNames.Add(f.Name);
                    fileNames.Add(f.FullName);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Napaka pri pridobivanju imen datotek. {0}", e);
            }

            //      ZA VSAKO DATOTEKO PRELETIMO REZULTATE IN JIH DOPOLNIMO PODATKE

            foreach (string pot in fileNames)
            {
                try
                {
                    Tekmovanje t = Tekmovanje(pot, ultra);

                    vmesniRezultati = Rezultati(pot, ref vsiTekmovalci, t, ultra);
                    vsiRezultati.AddRange(vmesniRezultati);

                    t.Rezultati = vmesniRezultati;

                    tekmovanja.Add(t);
                }
                catch (Exception)
                { }
            }
            return tekmovanja;
        }

        static void Main(string[] args)
        {
            //      RESETIRANJE BAZE
            bool resetBaze = false;
            if(resetBaze)
            {
                using(var db = new TriatlonDbContext())
                {
                    db.Tekmovalci.RemoveRange(db.Tekmovalci);

                    db.Rezultati.RemoveRange(db.Rezultati);

                    db.Tekmovanja.RemoveRange(db.Tekmovanja);

                    db.SaveChanges();
                }
            }

            bool samoDodajanjeUporabnikov = false;

            if (!samoDodajanjeUporabnikov)
            {
                Console.WriteLine("Pričetek branja datotek.");
                Stopwatch timer = Stopwatch.StartNew();

                //      POMOŽNI LISTI PRED BAZO
                List<Tekmovalec> vsiTekmovalci = new List<Tekmovalec>();

                List<Rezultat> vsiRezultati = new List<Rezultat>();

                List<Tekmovanje> vsaTekmovanja = new List<Tekmovanje>();
                List<Tekmovanje> ironmanTekmovanja = new List<Tekmovanje>();
                List<Tekmovanje> ironman703Tekmovanja = new List<Tekmovanje>();
                List<Tekmovanje> ultraTekmovanja = new List<Tekmovanje>();

                //      POTI DATOTEK
                string ironmanPath = @"C:\FERI\OZRA\Race-Results\Race-Results\IRONMAN\CSV";
                string ironman703Path = @"C:\FERI\OZRA\Race-Results\Race-Results\IRONMAN70.3\CSV";
                string ultraPath = @"C:\FERI\OZRA\Race-Results\Race-Results\Ultra-triathlon\CSV";



                //      BRANJE TEKMOVANJA IRONMAN

                ironmanTekmovanja = TekmovanjaEneMape(ironmanPath, ref vsiTekmovalci, ref vsiRezultati, false);
                Console.WriteLine("Končana mapa \"IRONMAN\"");


                //      BRANJE TEKMOVANJA IRONAMN70.3

                ironman703Tekmovanja = TekmovanjaEneMape(ironman703Path, ref vsiTekmovalci, ref vsiRezultati, false);          //POPRAVI, V IMENIH DATOTEK JE VEČ _______
                Console.WriteLine("Končana mapa \"IRONMAN70.3\"");


                //      BRANJE TEKMOVANJA ULTRA-TRIATLON

                ultraTekmovanja = TekmovanjaEneMape(ultraPath, ref vsiTekmovalci, ref vsiRezultati, true);
                Console.WriteLine("Končana mapa \"ULTRA-TRIATLON\"");



                //      STATISTIKA
                TimeSpan cas = timer.Elapsed;
                string preteceno = cas.ToString();
                Console.WriteLine("------------STATISTIKA PRIDOBIVANJA PODATKOV------------");
                Console.WriteLine();
                Console.WriteLine("Pretečen čas: {0}", preteceno);
                Console.WriteLine("Število vseh podatkov: {0}", vsiRezultati.Count);


                //      VSTAVLJANJE PODATKOV V BAZO
                bool napolniBazo = true;
                if (napolniBazo)
                {
                    using (var db = new TriatlonDbContext())
                    {
                        //db.Database.EnsureCreated();
                        Console.WriteLine("Začetek pisanja v bazo");

                        db.Tekmovalci.AddRange(vsiTekmovalci);
                        preteceno = cas.ToString();
                        Console.WriteLine("Zabeleženi vsi tekmovalci, prehod na rezultate");
                        Console.WriteLine("Pretečen čas: {0}", preteceno);

                        db.Tekmovanja.AddRange(ironmanTekmovanja);
                        preteceno = cas.ToString();
                        Console.WriteLine("Vpisana tekmovanja Ironman");
                        Console.WriteLine("Pretečen čas: {0}", preteceno);

                        db.Tekmovanja.AddRange(ironman703Tekmovanja);
                        preteceno = cas.ToString();
                        Console.WriteLine("Vpisana tekmovanja Ironman70.3");
                        Console.WriteLine("Pretečen čas: {0}", preteceno);

                        db.Tekmovanja.AddRange(ultraTekmovanja);
                        preteceno = cas.ToString();
                        Console.WriteLine("Vpisana tekmovanja Ultra-triatlon");
                        Console.WriteLine("Pretečen čas: {0}", preteceno);
                        Console.WriteLine();

                        //db.SaveChanges();                                 

                        timer.Stop();
                        TimeSpan casTotal = timer.Elapsed - cas;
                        string pretecenoTotal = casTotal.ToString();
                        Console.WriteLine("------------STATISTIKA ZAPISOVANJA PODATKOV V BAZO------------");
                        Console.WriteLine();
                        Console.WriteLine("Pretečen čas: {0}", pretecenoTotal);
                        Console.WriteLine();
                        Console.WriteLine("Zapisov v tabelo tekmovalci: {0}", db.Tekmovalci.Count());
                        Console.WriteLine("Zapisov v tabelo tekmovanja: {0}", db.Tekmovanja.Count());
                    }
                }

                using (var db = new TriatlonDbContext())
                {
                    Console.WriteLine("Zapisov v tabelo rezultati: {0}", db.Rezultati.Count());
                    Console.WriteLine("Zapisov v tabelo tekmovalci: {0}", db.Tekmovalci.Count());
                    Console.WriteLine("Zapisov v tabelo tekmovanja: {0}", db.Tekmovanja.Count());
                } 
            }
            else
            {

                Console.WriteLine("Ustvarjanje uporabnikov");
                Uporabnik u = new() { UporabniskoIme = "admin", Geslo = "admin", Admin = true };
                Uporabnik a = new() { UporabniskoIme = "user", Geslo = "user", Admin = false };
                Uporabnik b = new() { UporabniskoIme = "Miska123", Geslo = "123", Admin = false };
                Uporabnik c = new() { UporabniskoIme = "trojanskiSladoled15", Geslo = "15", Admin = false };
                Uporabnik d = new() { UporabniskoIme = "PrAvIkRalj", Geslo = "kralj", Admin = false };
                using (var db = new TriatlonDbContext())
                {

                    db.Uporabniki.Add(u);
                    db.Uporabniki.Add(a);
                    db.Uporabniki.Add(b);
                    db.Uporabniki.Add(c);
                    db.Uporabniki.Add(d);
                    db.SaveChanges();
                    Console.WriteLine();
                    Console.WriteLine("Uporabniki uspešno dodani");

                }
            }
        }
    }
}
